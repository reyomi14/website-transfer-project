# Memory: index.md
Updated: now

Modular card-based design with rounded corners. Space Grotesk 400+700. --radius: 1rem. All content in rounded-2xl card modules (white bg-card on off-white bg-background). Accent blocks (About, CTA, Limit, Footer) are full-width rounded-2xl cards with colored backgrounds inset in bg-background with px padding. Colors: off-white bg (40 9% 96%), near-black fg (60 8% 6%), green primary (152 56% 30%), orange FF8C00 accent-warm (33 100% 50%). Buttons: btn-primary/btn-outline 56px tall with rounded-xl. No shadows, no gradients. Icons: lucide-react with accent-warm or primary colors.
