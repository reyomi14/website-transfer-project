Preferences and rejections registry

- Never use букву "ё" — всегда заменять на "е" во всех текстах сайта (партнер, партнерство, etc.)
