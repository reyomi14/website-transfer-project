import { useScrollAnimation } from "@/hooks/useScrollAnimation";
import phoneNotification from "@/assets/phone-notification.png";
import phoneNotificationDesktop from "@/assets/phone-notification-desktop.png";
import dmitriyImg from "@/assets/dmitriy.png";
import SocialLinks from "@/components/SocialLinks";

const AboutProjectSection = () => {
  const { ref, isVisible } = useScrollAnimation();

  return (
    <section id="about" className="section-padding bg-background">
      <div className="container-landing" ref={ref}>
        {/* Desktop: card with rounded corners, green bg, text left + phone right */}
        <div className="hidden lg:block rounded-3xl bg-primary overflow-hidden">
          <div className="grid lg:grid-cols-[1fr_auto] items-center">
            {/* Text side */}
            <div className="p-8 xl:p-10 space-y-6">
              <div>
                <span className={`label-swiss text-primary-foreground block mb-3 transition-all duration-600 ${isVisible ? "opacity-100" : "opacity-0"}`}>
                  О проекте
                </span>
                <h2 className={`text-2xl xl:text-3xl font-bold text-primary-foreground transition-all duration-600 delay-100 ${isVisible ? "opacity-100 translate-y-0" : "opacity-0 translate-y-5"}`}>
                  Система, где владелец фуры{" "}
                  <span className="text-accent-warm">зарабатывает</span>
                </h2>
              </div>
              <div className={`space-y-4 transition-all duration-600 delay-200 ${isVisible ? "opacity-100 translate-y-0" : "opacity-0 translate-y-5"}`}>
                <p className="text-primary-foreground font-bold text-sm xl:text-base" style={{ lineHeight: 1.5 }}>
                  Мы&nbsp;не&nbsp;диспетчерская и&nbsp;не&nbsp;агрегатор
                </p>
                <p className="text-primary-foreground text-sm xl:text-base" style={{ lineHeight: 1.5 }}>
                  Орда Партнер Парк: команда, которая работает вместе с&nbsp;вами: дает стабильную загрузку, ведет работу с&nbsp;клиентами и&nbsp;документами, решает юридические вопросы
                </p>
                <p className="text-primary-foreground text-sm xl:text-base" style={{ lineHeight: 1.5 }}>
                  В&nbsp;нашей базе <span className="font-bold text-accent-warm">270+&nbsp;компаний-заказчиков</span>. Вы&nbsp;занимаетесь техникой и&nbsp;рейсами — мы&nbsp;берем на&nbsp;себя все остальное
                </p>
                <p className="text-primary-foreground/70 text-xs xl:text-sm leading-relaxed">
                  <span className="text-primary-foreground font-bold">Наши клиенты:&nbsp;</span>
                  Курьер Сервис Экспресс (КСЭ), Детский мир (ДМ), Командор, Возовоз, КИТ.ТК, СДЭК, Компания Скиф-Карго, Русал, ДНС, Яндекс, СУЭК, АРМТЭК
                </p>
                <div className="flex items-center gap-3 pt-2">
                  <img src={dmitriyImg} alt="Дмитрий Астахов" className="w-12 h-12 rounded-full object-cover shrink-0" />
                  <div>
                    <div className="text-primary-foreground font-bold text-sm">Дмитрий Астахов</div>
                    <div className="text-primary-foreground/60 text-xs">Руководитель отдела по работе с партнерами</div>
                  </div>
                </div>
              </div>
            </div>
            {/* Phone image — centered */}
            <div className={`flex items-center justify-center px-8 xl:px-10 py-8 transition-all duration-600 delay-300 ${isVisible ? "opacity-100 translate-y-0" : "opacity-0 translate-y-5"}`}>
              <img
                src={phoneNotificationDesktop}
                alt="Уведомление о новом заказе"
                className="w-96 xl:w-[28rem] h-auto"
                loading="lazy"
              />
            </div>
          </div>
        </div>

        {/* Mobile: card layout */}
        <div className="lg:hidden rounded-2xl bg-primary overflow-hidden">
          <div className="px-5 sm:px-8 pt-8 pb-2">
            <span className={`label-swiss text-primary-foreground block mb-4 transition-all duration-600 ${isVisible ? "opacity-100" : "opacity-0"}`}>
              О проекте
            </span>
            <h2 className={`section-heading text-primary-foreground transition-all duration-600 delay-100 ${isVisible ? "opacity-100 translate-y-0" : "opacity-0 translate-y-5"}`}>
              Система, где владелец фуры{" "}
              <span className="text-accent-warm">зарабатывает</span>
            </h2>
            <div className={`space-y-5 mt-6 transition-all duration-600 delay-200 ${isVisible ? "opacity-100 translate-y-0" : "opacity-0 translate-y-5"}`}>
              <p className="text-primary-foreground font-bold" style={{ fontSize: "var(--type-md)", lineHeight: 1.5 }}>
                Мы&nbsp;не&nbsp;диспетчерская и&nbsp;не&nbsp;агрегатор
              </p>
              <p className="text-primary-foreground" style={{ fontSize: "var(--type-md)", lineHeight: 1.5 }}>
                Орда Партнер Парк: команда, которая работает вместе с&nbsp;вами: дает стабильную загрузку, ведет работу с&nbsp;клиентами и&nbsp;документами, решает юридические вопросы
              </p>
              <p className="text-primary-foreground" style={{ fontSize: "var(--type-md)", lineHeight: 1.5 }}>
                В&nbsp;нашей базе <span className="font-bold text-accent-warm">270+&nbsp;компаний-заказчиков</span>. Вы&nbsp;занимаетесь техникой и&nbsp;рейсами — мы&nbsp;берем на&nbsp;себя все остальное
              </p>
              <p className="text-primary-foreground/70 text-sm leading-relaxed">
                <span className="text-primary-foreground font-bold">Наши клиенты:&nbsp;</span>
                Курьер Сервис Экспресс (КСЭ), Детский мир (ДМ), Командор, Возовоз, КИТ.ТК, СДЭК, Компания Скиф-Карго, Русал, ДНС, Яндекс, СУЭК, АРМТЭК
              </p>
              <div className="flex items-center gap-3 pt-2">
                <img src={dmitriyImg} alt="Дмитрий Астахов" className="w-12 h-12 rounded-full object-cover shrink-0" />
                  <div>
                    <div className="text-primary-foreground font-bold text-sm">Дмитрий Астахов</div>
                    <div className="text-primary-foreground/60 text-xs">Руководитель отдела по работе с партнерами</div>
                  </div>
              </div>
            </div>
          </div>
          <div className={`flex justify-center pt-4 pb-0 transition-all duration-600 delay-300 ${isVisible ? "opacity-100 translate-y-0" : "opacity-0 translate-y-5"}`}>
            <img
              src={phoneNotification}
              alt="Уведомление о новом заказе"
              className="w-48 h-auto"
              loading="lazy"
            />
          </div>
        </div>
      </div>
    </section>
  );
};

export default AboutProjectSection;