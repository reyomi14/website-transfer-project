const CaseBarChart = ({
  data,
  labels,
}: {
  data: number[];
  labels: string[];
}) => {
  if (!data.length) return null;

  const max = Math.max(...data);

  return (
    <div className="w-full">
      <span className="text-[10px] text-muted-foreground font-semibold mb-2 block">
        Выручка по месяцам, тыс. ₽
      </span>
      <div className="flex items-end gap-[3px] h-28">
        {data.map((v, i) => {
          const heightPct = Math.max((v / max) * 100, 4);

          return (
            <div key={i} className="flex-1 flex flex-col items-center h-full justify-end min-w-0">
              <span className="text-[8px] font-bold text-foreground tabular-nums whitespace-nowrap mb-0.5">
                {v.toLocaleString("ru-RU")}
              </span>
              <div
                className="w-full rounded-t-sm"
                style={{
                  height: `${heightPct}%`,
                  backgroundColor: "hsl(var(--primary))",
                }}
              />
              <span className="text-[7px] text-muted-foreground mt-0.5">
                {labels[i]}
              </span>
            </div>
          );
        })}
      </div>
    </div>
  );
};

export default CaseBarChart;