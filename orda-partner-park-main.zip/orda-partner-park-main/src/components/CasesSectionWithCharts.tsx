import { useScrollAnimation } from "@/hooks/useScrollAnimation";
import { useCaseEconomics } from "@/hooks/useCaseEconomics";
import { Link } from "react-router-dom";
import { User, Star, ExternalLink, BarChart3, Truck } from "lucide-react";
import CaseBarChart from "@/components/CaseSparkline";
import bardokinImg from "@/assets/bardokin.png";
import kuvaldinImg from "@/assets/kuvaldin.png";
import zinovievImg from "@/assets/zinoviev.png";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";

interface MonthlyRow {
  period: string;
  revenue: number;
  expenses: number;
  mileage: number;
  days: number;
  note?: string;
}

const kuvaldinMonthly: MonthlyRow[] = [
  { period: "05.2025", revenue: 90625, expenses: 133785, mileage: 3518, days: 5 },
  { period: "06.2025", revenue: 1040744, expenses: 458521, mileage: 21975, days: 30 },
  { period: "07.2025", revenue: 1009881, expenses: 470537, mileage: 19823, days: 28 },
  { period: "08.2025", revenue: 1121111, expenses: 490515, mileage: 21136, days: 30 },
  { period: "09.2025", revenue: 1093056, expenses: 726150, mileage: 18790, days: 27 },
  { period: "10.2025", revenue: 1013636, expenses: 685105, mileage: 13905, days: 22 },
  { period: "11.2025", revenue: 1082475, expenses: 622013, mileage: 16853, days: 26 },
  { period: "12.2025", revenue: 634722, expenses: 715764, mileage: 11031, days: 19, note: "отпуск" },
  { period: "01.2026", revenue: 1317778, expenses: 688134, mileage: 16425, days: 24 },
  { period: "02.2026", revenue: 1527222, expenses: 730598, mileage: 20886, days: 26 },
  { period: "03.2026", revenue: 1420344, expenses: 672595, mileage: 15773, days: 28 },
];

const bardokinMonthly: MonthlyRow[] = [
  { period: "09.2025", revenue: 877500, expenses: 519883, mileage: 16502, days: 23 },
  { period: "10.2025", revenue: 1254467, expenses: 563448, mileage: 19269, days: 29 },
  { period: "11.2025", revenue: 1087500, expenses: 982450, mileage: 17706, days: 25 },
  { period: "12.2025", revenue: 937667, expenses: 517896, mileage: 15170, days: 28 },
  { period: "01.2026", revenue: 1253115, expenses: 548932, mileage: 16724, days: 22 },
  { period: "02.2026", revenue: 987195, expenses: 608309, mileage: 11533, days: 20, note: "отпуск" },
  { period: "03.2026", revenue: 737420, expenses: 362167, mileage: 9350, days: 20, note: "отпуск" },
];

const monthlyData: Record<string, MonthlyRow[]> = {
  kuvaldin: kuvaldinMonthly,
  bardokin: bardokinMonthly,
};

function fmt(n: number): string {
  return n.toLocaleString("ru-RU") + " ₽";
}

function fmtKm(n: number): string {
  return n.toLocaleString("ru-RU") + " км";
}

function fmtMonth(period: string): string {
  const months: Record<string, string> = {
    "01": "янв",
    "02": "фев",
    "03": "мар",
    "04": "апр",
    "05": "май",
    "06": "июн",
    "07": "июл",
    "08": "авг",
    "09": "сен",
    "10": "окт",
    "11": "ноя",
    "12": "дек",
  };
  const [month, year] = period.split(".");
  return `${months[month] || month} ${year}`;
}

function getAvg(rows: MonthlyRow[]) {
  const avgRevenue = Math.round(rows.reduce((s, r) => s + r.revenue, 0) / rows.length);
  const avgExpenses = Math.round(rows.reduce((s, r) => s + r.expenses, 0) / rows.length);
  const avgProfit = avgRevenue - avgExpenses;
  const first = rows[0].period;
  const last = rows[rows.length - 1].period;
  return { avgRevenue, avgProfit, period: `${first} – ${last}` };
}

const quoteHighlights: Record<string, string> = {
  zinoviev: "Орда помогла с лизингом, дала заказы с первого дня и ведёт все документы",
  kuvaldin: "Теперь я зарабатываю не меньше, чем когда работал водителем, но это мой бизнес",
  bardokin: "доход стал выше, улучшилось материальное положение, появилась стабильность в завтрашнем дне",
};

const QuoteText = ({ text, highlight }: { text: string; highlight?: string }) => {
  if (!highlight || !text.includes(highlight)) {
    return <>{text}</>;
  }

  const [before, after] = text.split(highlight);

  return (
    <>
      {before}
      <strong className="font-bold text-foreground">{highlight}</strong>
      {after}
    </>
  );
};

const FleetVisual = () => (
  <div className="w-full">
    <span className="text-[10px] text-muted-foreground font-semibold mb-2 block">
      Парк техники
    </span>
    <div className="h-28 bg-background rounded-xl px-4 py-4 flex flex-col justify-center">
      <div className="grid grid-cols-3 gap-2 mb-3">
        {Array.from({ length: 3 }).map((_, i) => (
          <div key={i} className="h-12 rounded-lg bg-card flex items-center justify-center">
            <Truck className="w-7 h-7 text-primary" />
          </div>
        ))}
      </div>
      <span className="text-xs text-muted-foreground font-semibold text-center">
        Мини-парк из трех машин
      </span>
    </div>
  </div>
);

const MonthlyTable = ({ rows }: { rows: MonthlyRow[]; name: string }) => {
  const totalRevenue = rows.reduce((s, r) => s + r.revenue, 0);
  const totalMileage = rows.reduce((s, r) => s + r.mileage, 0);
  const totalDays = rows.reduce((s, r) => s + r.days, 0);

  return (
    <div className="w-full">
      <div className="overflow-x-auto -mx-6">
        <table className="w-full text-sm min-w-[400px]">
          <thead>
            <tr className="border-b border-border text-left">
              <th className="py-2.5 px-4 text-muted-foreground font-semibold text-xs">Период</th>
              <th className="py-2.5 px-4 text-muted-foreground font-semibold text-xs text-right">Выручка</th>
              <th className="py-2.5 px-4 text-muted-foreground font-semibold text-xs text-right">Пробег</th>
              <th className="py-2.5 px-4 text-muted-foreground font-semibold text-xs text-right">Дни</th>
            </tr>
          </thead>
          <tbody>
            {rows.map((r) => (
              <tr key={r.period} className="border-b border-border/50 hover:bg-muted/30 transition-colors">
                <td className="py-2 px-4 text-foreground font-medium text-xs">{fmtMonth(r.period)}</td>
                <td className="py-2 px-4 text-foreground tabular-nums text-xs text-right">{fmt(r.revenue)}</td>
                <td className="py-2 px-4 text-muted-foreground tabular-nums text-xs text-right">{fmtKm(r.mileage)}</td>
                <td className="py-2 px-4 text-muted-foreground tabular-nums text-xs text-right">
                  {r.days}
                  {r.note && <span className="text-[10px] text-muted-foreground/50 ml-1">({r.note})</span>}
                </td>
              </tr>
            ))}
          </tbody>
          <tfoot>
            <tr className="bg-muted/40">
              <td className="py-2.5 px-4 text-foreground font-bold text-xs">Итого</td>
              <td className="py-2.5 px-4 text-foreground font-bold tabular-nums text-xs text-right">{fmt(totalRevenue)}</td>
              <td className="py-2.5 px-4 text-muted-foreground font-bold tabular-nums text-xs text-right">{fmtKm(totalMileage)}</td>
              <td className="py-2.5 px-4 text-muted-foreground font-bold tabular-nums text-xs text-right">{totalDays}</td>
            </tr>
          </tfoot>
        </table>
      </div>
    </div>
  );
};

const cases = [
  {
    id: "zinoviev",
    name: "Зиновьев Андрей",
    type: "Партнер с несколькими сцепками",
    trucks: "3 сцепки",
    review: "Я долго искал формат, где можно запустить грузоперевозки, не разбираясь во всём самому. Орда помогла с лизингом, дала заказы с первого дня и ведёт все документы. Для меня это идеальная модель — я занимаюсь парком, а заказы и бумаги на них",
    revenue: "4 615 883 ₽",
    profit: "953 323 ₽",
    photo: zinovievImg,
    chartData: [] as number[],
    chartLabels: [] as string[],
  },
  {
    id: "kuvaldin",
    name: "Кувалдин Алексей",
    type: "ИП-водитель",
    trucks: "1 сцепка",
    review: "Я хотел уйти из найма и работать на себя, но боялся, что не потяну один. Орда помогла купить сцепку, дала заказы и сопровождает в каждом рейсе. Теперь я зарабатываю не меньше, чем когда работал водителем, но это мой бизнес",
    revenue: "1 317 778 ₽",
    profit: "629 644 ₽",
    photo: kuvaldinImg,
    chartData: [91, 1041, 1010, 1121, 1093, 1014, 1082, 635, 1318, 1527, 1420],
    chartLabels: ["май", "июн", "июл", "авг", "сен", "окт", "ноя", "дек", "янв", "фев", "мар"],
  },
  {
    id: "bardokin",
    name: "Бардокин Денис",
    type: "ИП-водитель",
    trucks: "1 сцепка",
    review: "Мне нравится, что Орда берёт на себя всю головную боль с заказчиками и документами. Я просто выхожу в рейс, зная, что загрузка будет, оплата придёт вовремя, а если что-то случится — помогут",
    revenue: "1 253 115 ₽",
    profit: "774 226 ₽",
    photo: bardokinImg,
    chartData: [878, 1254, 1088, 938, 1253, 987, 737],
    chartLabels: ["сен", "окт", "ноя", "дек", "янв", "фев", "мар"],
    yandexReview: {
      text: "В транспортной компании «Орда» раньше работал водителем фуры. С сентября месяца 2025 года стал партнером компании «Орда», компания помогла с приобретением грузового автомобиля. Также компания взяла все риски на себя, а от меня только требуется следить за техникой, и в срок доставлять груз согласно маршрута. Спустя полгода работы все опасения ушли на задний план, доход стал выше, улучшилось материальное положение, появилась стабильность в завтрашнем дне.",
      profileUrl: "https://yandex.ru/profile/62944486544",
      rating: 5,
      date: "14 апреля",
    },
  },
];

const CasesSection = () => {
  const { ref, isVisible } = useScrollAnimation();
  const sheetData = useCaseEconomics();

  return (
    <section id="cases" className="section-padding bg-background">
      <div className="container-landing" ref={ref}>
        <span className={`label-swiss text-muted-foreground block mb-4 transition-all duration-700 ${isVisible ? "opacity-100" : "opacity-0"}`}>
          Партнеры
        </span>
        <h2 className={`section-heading text-foreground mb-12 sm:mb-16 transition-all duration-700 delay-100 ${isVisible ? "opacity-100 translate-y-0" : "opacity-0 translate-y-6"}`}>
          Истории{" "}
          <span className="text-primary">и отзывы</span>{" "}
          партнеров
        </h2>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-12">
          {cases.map((c, i) => {
            const economics = sheetData[c.id];
            const hasMonthly = !!monthlyData[c.id];
            const monthly = monthlyData[c.id];
            const avg = hasMonthly ? getAvg(monthly) : null;

            const revenue = avg ? fmt(avg.avgRevenue) : (economics?.revenue || c.revenue);
            const profit = avg ? fmt(avg.avgProfit) : (economics?.profit || c.profit);

            return (
              <article
                key={i}
                className={`bg-card rounded-2xl overflow-hidden flex flex-col transition-all duration-500 ${isVisible ? "opacity-100 translate-y-0" : "opacity-0 translate-y-6"}`}
                style={{ transitionDelay: isVisible ? `${150 + i * 100}ms` : "0ms" }}
              >
                {/* Header */}
                <div className="p-5 pb-0">
                  <div className="flex items-center gap-3 mb-1">
                    {c.photo ? (
                      <img src={c.photo} alt={c.name} className="w-10 h-10 rounded-full object-cover shrink-0" />
                    ) : (
                      <div className="w-10 h-10 rounded-full bg-muted flex items-center justify-center shrink-0">
                        <User className="w-4 h-4 text-muted-foreground" />
                      </div>
                    )}
                    <div className="min-w-0">
                      <h3 className="text-foreground font-bold text-sm leading-tight truncate">{c.name}</h3>
                      <span className="text-xs text-muted-foreground">{c.type}</span>
                    </div>
                  </div>
                  <span className="inline-flex text-[10px] font-bold text-accent-warm bg-accent-warm/10 rounded-md px-2 py-1 mt-2">
                    {c.trucks}
                  </span>
                </div>

                {/* Visual */}
                <div className="px-5 pt-3">
                  {hasMonthly ? <CaseBarChart data={c.chartData} labels={c.chartLabels} /> : <FleetVisual />}
                </div>

                {/* Metrics */}
                <div className="px-5 pt-2 pb-2 grid grid-cols-2 gap-2">
                  <div className="bg-background rounded-xl px-3 py-2.5">
                    <span className="text-[10px] text-muted-foreground font-semibold block mb-0.5">
                      {hasMonthly ? "Ср. выручка/мес" : "Выручка"}
                    </span>
                    <span className="text-foreground font-bold text-sm tabular-nums">{revenue}</span>
                  </div>
                  <div className="bg-background rounded-xl px-3 py-2.5">
                    <span className="text-[10px] text-muted-foreground font-semibold block mb-0.5">
                      {hasMonthly ? "Ср. прибыль/мес" : "Прибыль"}
                    </span>
                    <span className="text-primary font-bold text-sm tabular-nums">{profit}</span>
                  </div>
                </div>

                {/* Period label + detailed economics button */}
                <div className="px-5 pb-3">
                  <span className="text-[10px] text-muted-foreground block mb-2">
                    За период {avg?.period || "09.2025 – 01.2026"}
                  </span>
                  {c.id !== "zinoviev" && (
                    <Dialog>
                      <DialogTrigger asChild>
                        <button className="w-full flex items-center justify-center gap-1.5 text-xs font-bold text-primary hover:text-primary/80 bg-primary/5 hover:bg-primary/10 transition-colors rounded-xl py-2">
                          <BarChart3 className="w-3.5 h-3.5" />
                          Подробная экономика
                        </button>
                      </DialogTrigger>
                      <DialogContent className="max-w-2xl max-h-[80vh] overflow-y-auto">
                        <DialogHeader>
                          <DialogTitle className="flex items-center gap-3">
                            {c.photo && (
                              <img src={c.photo} alt={c.name} className="w-8 h-8 rounded-full object-cover" />
                            )}
                            <div>
                              <span className="block text-base">{c.name}</span>
                              <span className="text-xs text-muted-foreground font-normal">{c.type} · {c.trucks}</span>
                            </div>
                          </DialogTitle>
                        </DialogHeader>
                        {hasMonthly ? (
                          <MonthlyTable rows={monthly} name={c.name} />
                        ) : (
                          <div className="grid grid-cols-2 gap-3">
                            <div className="bg-background rounded-xl px-4 py-3">
                              <span className="text-xs text-muted-foreground font-semibold block mb-1">Выручка</span>
                              <span className="text-foreground font-bold tabular-nums">{revenue}</span>
                            </div>
                            <div className="bg-background rounded-xl px-4 py-3">
                              <span className="text-xs text-muted-foreground font-semibold block mb-1">Прибыль</span>
                              <span className="text-primary font-bold tabular-nums">{profit}</span>
                            </div>
                          </div>
                        )}
                      </DialogContent>
                    </Dialog>
                  )}
                </div>

                {/* Review quote */}
                {!c.yandexReview && c.review && (
                  <div className="mx-5 mb-4 bg-background rounded-xl p-3">
                    <p className="text-xs text-muted-foreground leading-relaxed">
                      «<QuoteText text={c.review} highlight={quoteHighlights[c.id]} />»
                    </p>
                  </div>
                )}

                {/* Yandex review for Bardokin */}
                {c.yandexReview && (
                  <div className="mx-5 mb-4 bg-background rounded-xl p-3">
                    <div className="flex items-center gap-1.5 mb-2">
                      <div className="flex">
                        {Array.from({ length: c.yandexReview.rating }).map((_, j) => (
                          <Star key={j} className="w-4 h-4 fill-accent-warm text-accent-warm" />
                        ))}
                      </div>
                      <span className="text-[10px] text-muted-foreground">Яндекс Карты · {c.yandexReview.date}</span>
                    </div>
                    <p className="text-xs text-muted-foreground leading-relaxed">
                      «<QuoteText text={c.yandexReview.text} highlight={quoteHighlights[c.id]} />»
                    </p>
                    <a
                      href={c.yandexReview.profileUrl}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="inline-flex items-center gap-1 text-[10px] font-bold text-primary hover:text-primary/80 mt-2 transition-colors"
                    >
                      Читать на Яндекс Картах
                      <ExternalLink className="w-2.5 h-2.5" />
                    </a>
                  </div>
                )}

                {/* CTA */}
                <div className="mt-auto px-5 pb-5">
                  <Link
                    to={`/cases/${c.id}`}
                    className="w-full inline-flex items-center justify-center text-sm font-bold text-primary-foreground bg-primary hover:bg-primary/90 transition-colors rounded-xl py-2.5"
                  >
                    Читать историю →
                  </Link>
                </div>
              </article>
            );
          })}
        </div>

        <Link
          to="/cases"
          className="text-sm text-foreground font-bold border-b border-foreground pb-0.5 hover:text-primary hover:border-primary transition-colors"
        >
          Смотреть все истории →
        </Link>
      </div>
    </section>
  );
};

export default CasesSection;
