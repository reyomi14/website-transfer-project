import { useState } from "react";
import { useScrollAnimation } from "@/hooks/useScrollAnimation";
import ContactDialog from "@/components/ContactDialog";
import { X, Check, HelpCircle } from "lucide-react";
import {
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from "@/components/ui/tooltip";

interface Row {
  before: string;
  after: string;
  tooltip?: string;
}

const rows: Row[] = [
  { before: "Поиск заказов вручную по\u00A0чатам", after: "Плановая загрузка из\u00A0270+\u00A0заказчиков" },
  { before: "Простой 5–10\u00A0дней в\u00A0месяц", after: "Без порожняка" },
  { before: "Ожидание оплаты 30–60\u00A0дней", after: "Оплата через 15\u00A0дней после получения документов", tooltip: "Каждая перевозка оплачивается отдельно: через 15 дней после получения нами оригиналов документов." },
  { before: "Нет авансирования", after: "Аванс со\u00A0второго месяца" },
  { before: "Риски неплатежей", after: "Гарантированная оплата" },
  { before: "Споры и\u00A0бумажная рутина", after: "Документооборот на\u00A0нас" },
  { before: "«Делай что скажут»", after: "Вы\u00A0выбираете направление" },
  { before: "Топливо по\u00A0рыночной цене", after: "Скидки до\u00A020% на\u00A0ДТ через партнёрские АЗС" },
];

const ComparisonSection = () => {
  const { ref, isVisible } = useScrollAnimation();
  const [dialogOpen, setDialogOpen] = useState(false);

  return (
    <section className="section-padding bg-background">
      <div className="container-landing" ref={ref}>
        <span className={`label-swiss text-muted-foreground block mb-4 transition-all duration-600 ${isVisible ? "opacity-100" : "opacity-0"}`}>
          Сравнение
        </span>
        <h2 className={`section-heading text-foreground mb-14 transition-all duration-600 delay-100 ${isVisible ? "opacity-100 translate-y-0" : "opacity-0 translate-y-5"}`}>
          Что меняется,{" "}
          <br /><span className="text-primary">когда вы с&nbsp;нами</span>
        </h2>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div className={`bg-card rounded-2xl p-7 transition-all duration-500 ${isVisible ? "opacity-100 translate-y-0" : "opacity-0 translate-y-5"}`} style={{ transitionDelay: "150ms" }}>
            <h3 className="text-muted-foreground font-bold mb-6 text-base">Как сейчас</h3>
            <div className="space-y-0">
              {rows.map((row, i) => (
                <div key={i} className="flex items-start gap-3 py-3 border-b border-border last:border-b-0">
                  <div className="w-6 h-6 rounded-full bg-destructive/10 flex items-center justify-center shrink-0 mt-0.5">
                    <X className="w-3 h-3 text-destructive" />
                  </div>
                  <span className="text-muted-foreground text-sm leading-relaxed">{row.before}</span>
                </div>
              ))}
            </div>
          </div>

          <div className={`bg-primary rounded-2xl p-7 transition-all duration-500 ${isVisible ? "opacity-100 translate-y-0" : "opacity-0 translate-y-5"}`} style={{ transitionDelay: "250ms" }}>
            <h3 className="text-primary-foreground font-bold mb-6 text-base">С Орда Партнер Парк</h3>
            <div className="space-y-0">
              {rows.map((row, i) => (
                <div key={i} className="flex items-start gap-3 py-3 border-b border-primary-foreground/15 last:border-b-0">
                  <div className="w-6 h-6 rounded-full bg-primary-foreground/20 flex items-center justify-center shrink-0 mt-0.5">
                    <Check className="w-3 h-3 text-primary-foreground" />
                  </div>
                  <span className="text-primary-foreground font-semibold text-sm leading-relaxed">
                    {row.after}
                    {row.tooltip && (
                      <TooltipProvider delayDuration={0}>
                        <Tooltip>
                          <TooltipTrigger asChild>
                            <button type="button" className="inline-flex items-center ml-1.5 align-middle">
                              <HelpCircle className="w-4 h-4 text-primary-foreground/60 hover:text-primary-foreground transition-colors" />
                            </button>
                          </TooltipTrigger>
                          <TooltipContent side="top" className="max-w-[260px] text-sm">
                            {row.tooltip}
                          </TooltipContent>
                        </Tooltip>
                      </TooltipProvider>
                    )}
                  </span>
                </div>
              ))}
            </div>
          </div>
        </div>

        <div className="mt-12">
          <button onClick={() => setDialogOpen(true)} className="btn-primary rounded-xl">Хочу так же →</button>
        </div>
      </div>
      <ContactDialog open={dialogOpen} onOpenChange={setDialogOpen} title="Оставить заявку" goalId="comparison_same" />
    </section>
  );
};

export default ComparisonSection;
