import { useState, FormEvent, useRef } from "react";
import { Link } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";
import { trackFormInteraction, ymGoal } from "@/hooks/useYandexMetrika";
import { getUtm } from "@/hooks/useUtm";
import { getUserLocalDateTime, getUserTimeZone } from "@/lib/userTimeZone";
import PhoneInput from "@/components/PhoneInput";
import SubmissionSuccess from "@/components/SubmissionSuccess";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
} from "@/components/ui/dialog";

interface ContactDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  title?: string;
  goalId?: string;
}

const ContactDialog = ({ open, onOpenChange, title = "Оставить заявку", goalId = "dialog" }: ContactDialogProps) => {
  const [submitted, setSubmitted] = useState(false);
  const [sending, setSending] = useState(false);
  const [agreed, setAgreed] = useState(false);
  const nameRef = useRef<HTMLInputElement>(null);
  const phoneRef = useRef<HTMLInputElement>(null);

  const handleSubmit = async (e: FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    if (sending || !agreed) return;
    setSending(true);

    try {
      await supabase.functions.invoke('send-telegram', {
        body: {
          name: nameRef.current?.value || '',
          phone: phoneRef.current?.value || '',
          trucks: '',
          timezone: getUserTimeZone(),
          localDateTime: getUserLocalDateTime(),
          utm: getUtm(),
        },
      });
    } catch (err) {
      console.error('Submission error:', err);
    }

    setSending(false);
    setSubmitted(true);
    ymGoal(`form_submit_${goalId}`);
  };

  const handleClose = (val: boolean) => {
    onOpenChange(val);
    if (!val) {
      window.setTimeout(() => {
        setSubmitted(false);
        setSending(false);
        setAgreed(false);
      }, 300);
    }
  };

  return (
    <Dialog open={open} onOpenChange={handleClose}>
      <DialogContent className="sm:max-w-md max-h-[85dvh] overflow-y-auto rounded-2xl p-8">
        <DialogHeader>
          <DialogTitle className="font-bold" style={{ fontSize: "var(--type-lg)" }}>{title}</DialogTitle>
          <DialogDescription className="text-sm text-muted-foreground">
            Заполните форму, и мы свяжемся с вами в ближайшее время
          </DialogDescription>
        </DialogHeader>


        {submitted ? (
          <SubmissionSuccess variant="centered" />

        ) : (
          <div className="space-y-5 pt-2">
              <form
                id={`contact-dialog-form-${goalId}`}
                onSubmit={handleSubmit}
                onFocusCapture={() => trackFormInteraction(`form_interaction_${goalId}`)}
                onPointerDownCapture={() => trackFormInteraction(`form_interaction_${goalId}`)}
                className="space-y-5"
                autoComplete="off"
              >
              <div>
                <label className="label-swiss text-muted-foreground block mb-2">Имя</label>
                <input
                  ref={nameRef}
                  name="entry.406531471"
                  type="text"
                  required
                  placeholder="Ваше имя"
                  autoComplete="off"
                  className="w-full rounded-xl border border-border bg-muted/40 px-4 py-3 text-foreground placeholder:text-muted-foreground/50 focus:outline-none focus:ring-2 focus:ring-primary/30 focus:border-primary transition-all"
                />
              </div>
              <div>
                <label className="label-swiss text-muted-foreground block mb-2">Телефон</label>
                <PhoneInput
                  ref={phoneRef}
                  name="entry.215230857"
                  required
                  autoComplete="off"
                  className="w-full rounded-xl border border-border bg-muted/40 px-4 py-3 text-foreground placeholder:text-muted-foreground/50 focus:outline-none focus:ring-2 focus:ring-primary/30 focus:border-primary transition-all"
                />
              </div>
              <label className="flex items-start gap-3 cursor-pointer select-none">
                <input
                  type="checkbox"
                  checked={agreed}
                  onChange={(e) => setAgreed(e.target.checked)}
                  className="mt-1 h-4 w-4 shrink-0 rounded border border-border accent-primary"
                />
                <span className="text-xs text-muted-foreground leading-snug">
                  Я даю согласие на обработку моих персональных данных в соответствии с{" "}
                  <Link to="/consent" className="text-primary underline hover:text-primary/80" target="_blank">
                    согласием на обработку персональных данных
                  </Link>{" "}
                  и{" "}
                  <Link to="/privacy" className="text-primary underline hover:text-primary/80" target="_blank">
                    политикой конфиденциальности
                  </Link>
                </span>
              </label>
              <button
                id="contact-dialog-submit"
                type="submit"
                disabled={sending || !agreed}
                className="w-full h-14 rounded-xl bg-primary text-primary-foreground text-sm font-bold whitespace-nowrap flex items-center justify-center hover:bg-primary/90 active:scale-[0.98] transition-all disabled:opacity-60"
              >
                {sending ? "Отправка..." : "Отправить заявку →"}
              </button>
            </form>
          </div>
        )}
      </DialogContent>
    </Dialog>
  );
};

export default ContactDialog;
