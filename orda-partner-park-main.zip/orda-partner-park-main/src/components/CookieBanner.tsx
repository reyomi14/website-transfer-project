import { useState, useEffect } from "react";

const CookieBanner = () => {
  const [visible, setVisible] = useState(false);

  useEffect(() => {
    if (!localStorage.getItem("cookies_accepted")) setVisible(true);
  }, []);

  if (!visible) return null;

  const accept = () => {
    localStorage.setItem("cookies_accepted", "1");
    setVisible(false);
  };

  return (
    <div className="fixed bottom-4 left-4 right-4 sm:left-auto sm:right-4 sm:max-w-sm z-50 bg-card border border-border rounded-xl shadow-lg px-4 py-3 flex items-center gap-3 text-sm animate-fade-in">
      <span className="text-muted-foreground leading-snug">
        Мы используем cookies для улучшения работы сайта
      </span>
      <button onClick={accept} className="shrink-0 bg-primary text-primary-foreground px-3 py-1.5 rounded-lg text-xs font-medium hover:opacity-90 transition-opacity">
        Ок
      </button>
    </div>
  );
};

export default CookieBanner;
