import { useState, FormEvent, useRef } from "react";
import { Link } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";
import { trackFormInteraction, ymGoal } from "@/hooks/useYandexMetrika";
import { getUtm } from "@/hooks/useUtm";
import dmitriyImg from "@/assets/dmitriy.png";
import SocialLinks from "@/components/SocialLinks";
import { getUserLocalDateTime, getUserTimeZone } from "@/lib/userTimeZone";
import PhoneInput from "@/components/PhoneInput";
import SubmissionSuccess from "@/components/SubmissionSuccess";

const CtaSection = () => {
  const [submitted, setSubmitted] = useState(false);
  const [sending, setSending] = useState(false);
  const [agreed, setAgreed] = useState(false);
  const nameRef = useRef<HTMLInputElement>(null);
  const phoneRef = useRef<HTMLInputElement>(null);

  const handleSubmit = async (e: FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    if (sending || !agreed) return;
    setSending(true);

    try {
      await supabase.functions.invoke('send-telegram', {
        body: {
          name: nameRef.current?.value || '',
          phone: phoneRef.current?.value || '',
          trucks: '',
          timezone: getUserTimeZone(),
          localDateTime: getUserLocalDateTime(),
          utm: getUtm(),
        },
      });
    } catch (err) {
      console.error('Submission error:', err);
    }

    setSending(false);
    setSubmitted(true);
    ymGoal("form_submit_cta");
  };

  return (
    <section id="cta" className="section-padding bg-primary text-primary-foreground">
      <div className="container-landing">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 lg:gap-16">
          <div className="lg:col-span-5 space-y-6">
            <span className="text-sm font-semibold text-primary-foreground/70">Заявка</span>
            <h2 className="font-bold text-primary-foreground leading-[1.1] tracking-[-0.02em]" style={{ fontSize: "var(--type-2xl)" }}>
              Готовы обсудить партнерство?
            </h2>
            <p className="leading-relaxed text-xl font-sans text-secondary rounded-none font-medium">
              Обсудим вместе цифры, экономику и&nbsp;посчитаем ставки по&nbsp;направлениям
            </p>

            <div className="border-t border-primary-foreground/20 pt-6 flex items-center gap-4">
              <img src={dmitriyImg} alt="Дмитрий Астахов" className="w-14 h-14 rounded-full object-cover shrink-0" />
              <div>
                <div className="font-bold text-primary-foreground">Дмитрий Астахов</div>
                <div className="text-xs text-primary-foreground/60">Руководитель отдела по работе с партнерами</div>
                <a href="tel:89233350610" className="text-sm text-primary-foreground hover:text-accent-warm transition-colors block mt-1">
                  8-923-335-06-10
                </a>
                <div className="mt-2">
                  <SocialLinks imgSize="w-7 h-7" />
                </div>
              </div>
            </div>
          </div>

          <div className="lg:col-span-6 lg:col-start-7">
            <div className="bg-card text-card-foreground p-8 sm:p-10 rounded-2xl">
              
              {submitted ? (
                <SubmissionSuccess variant="centered" className="py-6" />
              ) : (
                <div className="space-y-5">
                  <form id="partner-cta-form" onSubmit={handleSubmit} onFocusCapture={() => trackFormInteraction("form_interaction_cta")} onPointerDownCapture={() => trackFormInteraction("form_interaction_cta")} className="space-y-5" autoComplete="off">
                    <div>
                      <label className="text-sm font-semibold text-muted-foreground block mb-2">Имя</label>
                      <input ref={nameRef} name="entry.406531471" type="text" required placeholder="Ваше имя" autoComplete="off"
                        className="w-full rounded-xl border border-border bg-muted/40 px-4 py-3 text-foreground placeholder:text-muted-foreground/40 focus:outline-none focus:ring-2 focus:ring-primary/30 focus:border-primary transition-all" />
                    </div>
                    <div>
                      <label className="text-sm font-semibold text-muted-foreground block mb-2">Телефон</label>
                      <PhoneInput ref={phoneRef} name="entry.215230857" required autoComplete="off"
                        className="w-full rounded-xl border border-border bg-muted/40 px-4 py-3 text-foreground placeholder:text-muted-foreground/40 focus:outline-none focus:ring-2 focus:ring-primary/30 focus:border-primary transition-all" />
                    </div>
                    <label className="flex items-start gap-3 cursor-pointer select-none">
                      <input
                        type="checkbox"
                        checked={agreed}
                        onChange={(e) => setAgreed(e.target.checked)}
                        className="mt-1 h-4 w-4 shrink-0 rounded border border-border accent-primary"
                      />
                      <span className="text-xs text-muted-foreground leading-snug">
                        Я даю согласие на обработку моих персональных данных в соответствии с{" "}
                        <Link to="/consent" className="text-primary underline hover:text-primary/80" target="_blank">
                          согласием на обработку персональных данных
                        </Link>{" "}
                        и{" "}
                        <Link to="/privacy" className="text-primary underline hover:text-primary/80" target="_blank">
                          политикой конфиденциальности
                        </Link>
                      </span>
                    </label>
                    <button id="partner-cta-submit" type="submit" disabled={!agreed || sending} className="btn-primary w-full rounded-xl active:scale-[0.98] transition-all disabled:opacity-60">
                      {sending ? "Отправка..." : "Стать партнером →"}
                    </button>
                  </form>
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default CtaSection;
