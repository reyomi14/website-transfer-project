import { useState, useEffect, useRef, FormEvent } from "react";
import { Link } from "react-router-dom";
import { useScrollAnimation } from "@/hooks/useScrollAnimation";
import { useGoogleSheet } from "@/hooks/useGoogleSheet";
import { supabase } from "@/integrations/supabase/client";
import { trackFormInteraction, ymGoal } from "@/hooks/useYandexMetrika";
import { getUtm } from "@/hooks/useUtm";
import { getUserLocalDateTime, getUserTimeZone } from "@/lib/userTimeZone";
import PhoneInput from "@/components/PhoneInput";
import { Lock, RefreshCw, User, Phone, Clock, ShieldCheck, Truck } from "lucide-react";
import ratesPreview from "@/assets/rates-preview.png";
import SubmissionSuccess from "@/components/SubmissionSuccess";

const rateCtaCopy = {
  titleAccent: "Узнайте ставку",
  titleRest: "по вашему маршруту",
  subtitle: "Пришлём актуальные цифры за реф и тент по любому направлению России. Обычно отвечаем в течение часа.",
  button: "Получить ставку",
};

function getUpdateDate(): string {
  const anchor = new Date(2026, 3, 3); // 3 апреля 2026
  const now = new Date();
  const diffDays = Math.floor((now.getTime() - anchor.getTime()) / 86400000);
  const periods = Math.max(0, Math.floor(diffDays / 3));
  const d = new Date(anchor.getTime() + periods * 3 * 86400000);
  return `${String(d.getDate()).padStart(2, "0")}.${String(d.getMonth() + 1).padStart(2, "0")}.${d.getFullYear()}`;
}

const EconomicsSection = () => {
  const { ref, isVisible } = useScrollAnimation();
  const { routes, loading } = useGoogleSheet();
  const [pulse, setPulse] = useState(false);
  const [submitted, setSubmitted] = useState(false);
  const [sending, setSending] = useState(false);
  const [agreed, setAgreed] = useState(false);
  const [name, setName] = useState("");
  const phoneRef = useRef<HTMLInputElement>(null);

  const handleRateSubmit = async (e: FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    if (sending || !agreed) return;
    setSending(true);

    try {
      await supabase.functions.invoke("send-telegram", {
        body: {
          name: name || "Заявка на ставку по маршруту",
          phone: phoneRef.current?.value || "",
          trucks: "",
          formType: "rate_request",
          timezone: getUserTimeZone(),
          localDateTime: getUserLocalDateTime(),
          utm: getUtm(),
        },
      });
    } catch (err) {
      console.error("Submission error:", err);
    }

    setSending(false);
    setSubmitted(true);
    ymGoal("form_submit_rates");
  };

  useEffect(() => {
    if (!isVisible) return;
    const interval = setInterval(() => {
      setPulse(true);
      setTimeout(() => setPulse(false), 1000);
    }, 3000);
    return () => clearInterval(interval);
  }, [isVisible]);

  return (
    <section id="economics" className="section-padding bg-background">
      <div className="container-landing" ref={ref}>
        <span className={`label-swiss text-muted-foreground block mb-4 transition-all duration-600 ${isVisible ? "opacity-100" : "opacity-0"}`}>
          Экономика
        </span>
        <h2 className={`section-heading text-foreground mb-3 transition-all duration-600 delay-100 ${isVisible ? "opacity-100 translate-y-0" : "opacity-0 translate-y-5"}`}>
          Ставки наших маршрутов{" "}
          <span className="text-primary">за&nbsp;неделю</span>
        </h2>
        <p className={`text-muted-foreground text-sm mb-10 transition-all duration-600 delay-150 ${isVisible ? "opacity-100" : "opacity-0"}`}>
          Работаем со всеми регионами России
        </p>

        {/* Live update badge */}
        <div className={`inline-flex items-center gap-3 bg-card rounded-full px-5 py-3 mb-10 transition-all duration-500 delay-150 ${isVisible ? "opacity-100 translate-y-0" : "opacity-0 translate-y-5"}`}>
          <span className="text-sm text-foreground font-bold">Информация обновлена {getUpdateDate()}</span>
          <RefreshCw className={`w-3.5 h-3.5 text-primary transition-transform duration-700 ${pulse ? "rotate-180" : ""}`} />
        </div>

        <div className={`grid grid-cols-1 md:grid-cols-3 gap-4 mb-14 ${loading ? "opacity-50" : ""}`}>
          {routes.map((r, i) => (
            <div
              key={i}
              className={`bg-card rounded-2xl p-7 flex flex-col transition-all duration-500 ${isVisible ? "opacity-100 translate-y-0" : "opacity-0 translate-y-5"}`}
              style={{ transitionDelay: isVisible ? `${200 + i * 80}ms` : "0ms" }}
            >
              {/* Route name */}
              <h3 className="text-foreground font-bold leading-tight min-h-[2.8em] mb-1 text-base">
                {r.route}
              </h3>

              {/* Km — normal readable text */}
              <span className="text-sm text-muted-foreground mb-6">
                {r.km}
              </span>

              {/* Revenue rows */}
              <div className="mt-auto space-y-3">
                <div className="bg-background rounded-xl px-5 py-4 flex items-baseline justify-between">
                  <span className="text-sm text-muted-foreground font-semibold">Выручка реф</span>
                  <span className="text-accent-warm font-bold tabular-nums text-lg md:text-[length:var(--type-lg)]">
                    {r.profitRef} <span className="text-muted-foreground text-xs">₽</span>
                  </span>
                </div>
                {r.profitTent && (
                  <div className="bg-background rounded-xl px-5 py-4 flex items-baseline justify-between">
                    <span className="text-sm text-muted-foreground font-semibold">Выручка тент</span>
                    <span className="text-accent-warm font-bold tabular-nums text-lg md:text-[length:var(--type-lg)]">
                      {r.profitTent} <span className="text-muted-foreground text-xs">₽</span>
                    </span>
                  </div>
                )}
              </div>
            </div>
          ))}
        </div>

        <div className={`relative bg-card border border-border rounded-3xl p-4 sm:p-8 lg:px-11 lg:py-12 grid grid-cols-1 lg:grid-cols-[1fr_1.15fr] gap-4 lg:gap-12 items-center transition-all duration-500 delay-200 ${isVisible ? "opacity-100 translate-y-0" : "opacity-0 translate-y-5"}`}>
          {/* LEFT — form */}
          <div className="order-2 lg:order-1">
            <h3 className="text-xl sm:text-2xl lg:text-[length:var(--type-h2)] font-bold leading-tight text-foreground mb-2 lg:mb-5">
              <span className="text-primary">{rateCtaCopy.titleAccent}</span>{" "}
              {rateCtaCopy.titleRest}
            </h3>
            <p className="text-muted-foreground text-xs sm:text-base leading-relaxed mb-4 lg:mb-7 max-w-[520px]">
              {rateCtaCopy.subtitle}
            </p>

            {submitted ? (
              <SubmissionSuccess variant="card" />
            ) : (
              <form
                id="rates-cta-form"
                onSubmit={handleRateSubmit}
                onFocusCapture={() => trackFormInteraction("form_interaction_rates")}
                onPointerDownCapture={() => trackFormInteraction("form_interaction_rates")}
                className="space-y-2 lg:space-y-3"
              >
                <div className="relative">
                  <span className="absolute left-2 top-1/2 -translate-y-1/2 w-8 h-8 lg:w-9 lg:h-9 rounded-full bg-primary/10 flex items-center justify-center">
                    <User className="w-4 h-4 text-primary" />
                  </span>
                  <input
                    type="text"
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    placeholder="Ваше имя"
                    autoComplete="name"
                    className="w-full rounded-2xl border border-border bg-background pl-12 lg:pl-14 pr-4 py-3 lg:py-4 text-foreground placeholder:text-muted-foreground/60 focus:outline-none focus:ring-2 focus:ring-primary/30 focus:border-primary transition-all"
                  />
                </div>

                <div className="relative">
                  <span className="absolute left-2 top-1/2 -translate-y-1/2 w-8 h-8 lg:w-9 lg:h-9 rounded-full bg-primary/10 flex items-center justify-center z-10">
                    <Phone className="w-4 h-4 text-primary" />
                  </span>
                  <PhoneInput
                    ref={phoneRef}
                    name="entry.215230857"
                    required
                    autoComplete="off"
                    className="w-full rounded-2xl border border-border bg-background pl-12 lg:pl-14 pr-4 py-3 lg:py-4 text-foreground placeholder:text-muted-foreground/60 focus:outline-none focus:ring-2 focus:ring-primary/30 focus:border-primary transition-all"
                  />
                </div>

                <button
                  id="rates-cta-submit"
                  type="submit"
                  disabled={sending || !agreed}
                  className="btn-primary w-full rounded-2xl py-3 lg:py-4 text-base disabled:opacity-60"
                >
                  {sending ? "Отправляем..." : rateCtaCopy.button}
                </button>

                <div className="hidden lg:flex flex-wrap gap-2 pt-2">
                  <span className="inline-flex items-center gap-2 bg-background rounded-full px-4 py-2 text-xs font-bold text-foreground">
                    <Clock className="w-3.5 h-3.5 text-primary" /> Ответ в течение часа
                  </span>
                  <span className="inline-flex items-center gap-2 bg-background rounded-full px-4 py-2 text-xs font-bold text-foreground">
                    <ShieldCheck className="w-3.5 h-3.5 text-primary" /> Без спама
                  </span>
                  <span className="inline-flex items-center gap-2 bg-background rounded-full px-4 py-2 text-xs font-bold text-foreground">
                    <Truck className="w-3.5 h-3.5 text-primary" /> Реф и тент
                  </span>
                </div>

                <label className="flex items-start gap-2 cursor-pointer select-none pt-1 lg:pt-2">
                  <input
                    type="checkbox"
                    checked={agreed}
                    onChange={(e) => setAgreed(e.target.checked)}
                    className="mt-1 h-4 w-4 shrink-0 rounded border border-border accent-primary"
                  />
                  <span className="text-[10px] lg:text-xs text-muted-foreground leading-snug">
                    Я даю согласие на обработку моих персональных данных в соответствии с{" "}
                    <Link to="/consent" className="text-primary underline hover:text-primary/80" target="_blank">
                      согласием на обработку персональных данных
                    </Link>{" "}
                    и{" "}
                    <Link to="/privacy" className="text-primary underline hover:text-primary/80" target="_blank">
                      политикой конфиденциальности
                    </Link>
                  </span>
                </label>
              </form>
            )}
          </div>

          {/* RIGHT — rates preview image (above form on mobile, key trigger) */}
          <div className="relative w-full select-none pointer-events-none order-1 lg:order-2 lg:scale-[1.08] lg:origin-center lg:-my-2">
            <img
              src={ratesPreview}
              alt="Превью таблицы актуальных ставок по направлениям"
              loading="lazy"
              className="w-full h-auto"
            />
          </div>
        </div>
      </div>
    </section>
  );
};

export default EconomicsSection;
