import { useState } from "react";
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";
import { useScrollAnimation } from "@/hooks/useScrollAnimation";
import ContactDialog from "@/components/ContactDialog";

const faqs = [
  { q: "Я потеряю самостоятельность?", a: "Нет. Вы остаетесь полноценным владельцем своего бизнеса" },
  { q: "Если заказчик не заплатит?", a: "Оплата в срок, даже если с нами не рассчитался заказчик. Ваша задача доставить груз и подписать документы" },
  { q: "Это диспетчерская?", a: "Мы больше чем диспетчерская. Мы выстраиваем систему: работа с заказчиками, логистическое сопровождение, помощь в ЧП, страховки, пропуска, юридическая поддержка" },
  { q: "Как долго ждать оплату?", a: "15 дней после получения оригиналов документов. Аванс доступен со второго месяца" },
];

const FaqSection = () => {
  const { ref, isVisible } = useScrollAnimation();
  const [dialogOpen, setDialogOpen] = useState(false);

  return (
    <section id="faq" className="section-padding bg-background">
      <div className="container-landing" ref={ref}>
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 lg:gap-16">
          <div className="lg:col-span-4">
            <h2 className={`section-heading text-foreground transition-all duration-600 delay-100 ${isVisible ? "opacity-100 translate-y-0" : "opacity-0 translate-y-5"}`}>
              Ответы на{" "}
              <span className="text-primary">вопросы</span>
            </h2>
          </div>

          <div className="lg:col-span-7 lg:col-start-6">
            <div className="bg-card rounded-2xl overflow-hidden">
              <Accordion type="single" collapsible>
                {faqs.map((faq, i) => (
                  <AccordionItem key={i} value={`faq-${i}`}
                    className={`border-b border-border last:border-b-0 transition-all duration-500 ${isVisible ? "opacity-100 translate-y-0" : "opacity-0 translate-y-5"}`}
                    style={{ transitionDelay: isVisible ? `${200 + i * 50}ms` : "0ms" }}>
                    <AccordionTrigger className="text-sm font-bold text-foreground hover:no-underline hover:text-primary px-7 py-6 text-left">
                      <span className="flex items-start gap-4">
                        <span className="text-sm text-accent-warm font-bold shrink-0 pt-0.5 tabular-nums">{String(i + 1).padStart(2, "0")}</span>
                        {faq.q}
                      </span>
                    </AccordionTrigger>
                    <AccordionContent className="text-muted-foreground text-sm px-7 pb-6 pl-[4.5rem] leading-relaxed">
                      {faq.a}
                    </AccordionContent>
                  </AccordionItem>
                ))}
              </Accordion>
            </div>

            <div className="mt-10">
              <button onClick={() => setDialogOpen(true)} className="btn-secondary rounded-xl">
                Остались вопросы? →
              </button>
            </div>
          </div>
        </div>
      </div>
      <ContactDialog open={dialogOpen} onOpenChange={setDialogOpen} title="Задать вопрос" goalId="faq_question" />
    </section>
  );
};

export default FaqSection;
