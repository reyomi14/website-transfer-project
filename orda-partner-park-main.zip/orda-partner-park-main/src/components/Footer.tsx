import { Link } from "react-router-dom";

const Footer = () => (
  <footer className="bg-foreground text-background px-5 sm:px-8 lg:px-12 py-14 sm:py-20">
    <div className="container-landing">
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-10 sm:gap-12 mb-14">
        <div>
          <span className="font-bold text-lg tracking-tight block text-background">
            Орда Партнер Парк
          </span>
        </div>

        <div>
          <span className="text-sm font-semibold text-background/40 block mb-4">Навигация</span>
          <div className="space-y-2">
            {[
              { label: "Для кого", hash: "#whom" },
              { label: "Как работает", hash: "#how" },
              { label: "Экономика", hash: "#economics" },
              { label: "Ответы на вопросы", hash: "#faq" },
            ].map((l) => (
              <a key={l.hash} href={l.hash}
                className="block text-sm text-background/60 hover:text-background transition-colors">
                {l.label}
              </a>
            ))}
            <Link to="/cases" className="block text-sm text-background/60 hover:text-background transition-colors">
              Кейсы
            </Link>
          </div>
        </div>

        <div>
          <span className="text-sm font-semibold text-background/40 block mb-4">Контакт</span>
          <div className="space-y-2 text-sm">
            <div className="text-background font-bold">Дмитрий Астахов</div>
            <a href="tel:89233350610" className="block text-background/60 hover:text-background transition-colors">
              8-923-335-06-10
            </a>
          </div>
        </div>
      </div>

      {/* Company info */}
      <div className="border-t border-background/10 pt-6 mt-10 grid grid-cols-1 sm:grid-cols-2 gap-6">
        <div className="space-y-1 text-xs text-background/40">
          <div className="text-background/60 font-semibold mb-2">ООО ТК «Орда»</div>
          <div>ОГРН: 1162468090619</div>
          <div>ИНН: 2459020189 / КПП: 245901001</div>
          <div>662314, Красноярский край, г. Шарыпово, МКР. 5-й, зд. 3, офис 1</div>
        </div>
        <div className="space-y-1 text-xs text-background/40 sm:text-right">
          <Link to="/privacy" className="block text-background/60 hover:text-background transition-colors">
            Политика конфиденциальности
          </Link>
          <div>© {new Date().getFullYear()} Орда Партнер Парк</div>
        </div>
      </div>
    </div>
  </footer>
);

export default Footer;
