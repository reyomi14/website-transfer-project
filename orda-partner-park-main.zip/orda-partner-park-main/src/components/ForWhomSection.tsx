import { useState } from "react";
import { useScrollAnimation } from "@/hooks/useScrollAnimation";
import ContactDialog from "@/components/ContactDialog";
import { Truck, Clock, TrendingUp, FileText, Scale } from "lucide-react";

const cards = [
  { icon: Truck, text: "Вам нужен стабильный поток заказов" },
  { icon: Clock, text: "Вы\u00A0устали от\u00A0простоев" },
  { icon: TrendingUp, text: "Вы\u00A0хотите предсказуемый доход и\u00A0гарантию оплаты" },
  { icon: FileText, text: "Вам надоело разбираться с\u00A0документами" },
  { icon: Scale, text: "Вы\u00A0проигрываете крупным компаниям по\u00A0стоимости топлива, авто и\u00A0ГСМ" },
];

const ForWhomSection = () => {
  const { ref, isVisible } = useScrollAnimation();
  const [dialogOpen, setDialogOpen] = useState(false);

  return (
    <section id="whom" className="section-padding bg-background">
      <div className="container-landing" ref={ref}>
        <span className={`label-swiss text-muted-foreground block mb-4 transition-all duration-600 ${isVisible ? "opacity-100" : "opacity-0"}`}>
          Для кого
        </span>
        <h2 className={`section-heading text-foreground mb-14 transition-all duration-600 delay-100 ${isVisible ? "opacity-100 translate-y-0" : "opacity-0 translate-y-5"}`}>
          Кому подойдет{" "}
          <span className="text-primary">партнерство</span>
        </h2>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {cards.map((card, i) => {
            const Icon = card.icon;
            return (
              <div
                key={i}
                className={`rounded-2xl p-7 flex flex-col gap-6 transition-all duration-500 ${i === 0 ? "bg-primary text-primary-foreground" : "bg-card"} ${isVisible ? "opacity-100 translate-y-0" : "opacity-0 translate-y-5"}`}
                style={{ transitionDelay: isVisible ? `${200 + i * 70}ms` : "0ms" }}
              >
                <div className={`w-12 h-12 rounded-xl flex items-center justify-center ${i === 0 ? "bg-primary-foreground/15" : "bg-accent-warm/10"}`}>
                  <Icon className={`w-6 h-6 ${i === 0 ? "text-primary-foreground" : "text-accent-warm"}`} strokeWidth={1.5} />
                </div>
                <p className={`font-bold leading-snug ${i === 0 ? "text-primary-foreground" : "text-foreground"}`} style={{ fontSize: "var(--type-md)" }}>
                  {card.text}
                </p>
              </div>
            );
          })}
        </div>

        <div className="mt-12">
          <button onClick={() => setDialogOpen(true)} className="btn-secondary rounded-xl">
            Проверить, подхожу ли я →
          </button>
        </div>
      </div>
      <ContactDialog open={dialogOpen} onOpenChange={setDialogOpen} title="Проверить, подхожу ли я" goalId="forwhom_check" />
    </section>
  );
};

export default ForWhomSection;