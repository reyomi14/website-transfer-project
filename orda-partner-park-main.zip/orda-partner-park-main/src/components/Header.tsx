import { useState } from "react";
import { Link, useLocation, useNavigate } from "react-router-dom";
import { Menu, X } from "lucide-react";
import logo from "@/assets/logo.png";
import ContactDialog from "@/components/ContactDialog";
import SocialLinks from "@/components/SocialLinks";

const sectionLinks = [
  { label: "Для кого", hash: "#whom" },
  { label: "Как работает", hash: "#how" },
  { label: "Экономика", hash: "#economics" },
  { label: "Вопросы", hash: "#faq" },
];

const Header = () => {
  const [open, setOpen] = useState(false);
  const [contactOpen, setContactOpen] = useState(false);
  const location = useLocation();
  const navigate = useNavigate();

  const go = (hash: string) => {
    setOpen(false);
    if (location.pathname === "/") {
      const el = document.querySelector(hash);
      if (el) {
        const y = el.getBoundingClientRect().top + window.scrollY - 64;
        window.scrollTo({ top: y, behavior: "smooth" });
      }
    } else {
      navigate("/" + hash);
    }
  };

  return (
    <>
    <header className="fixed top-0 left-0 right-0 z-50 bg-background border-b border-border">
      <div className="container-landing flex items-center justify-between h-16 px-5 sm:px-8 lg:px-12">
        <Link to="/" className="shrink-0">
          <img src={logo} alt="Орда Партнер Парк" className="h-12 object-contain" />
        </Link>

        <nav className="hidden md:flex items-center gap-4 lg:gap-5">
          {sectionLinks.map((l) => (
            <button
              key={l.hash}
              onClick={() => go(l.hash)}
              className="text-sm text-muted-foreground hover:text-foreground transition-colors"
            >
              {l.label}
            </button>
          ))}
          <Link
            to="/cases"
            className={`text-sm transition-colors ${location.pathname.startsWith("/cases") ? "text-foreground font-bold" : "text-muted-foreground hover:text-foreground"}`}
          >
            Истории партнеров
          </Link>
          <SocialLinks imgSize="w-6 h-6" gap="gap-2" />
          <a href="tel:89233350610" className="text-sm text-foreground font-bold whitespace-nowrap hover:text-primary transition-colors">
            8-923-335-06-10
          </a>
          <button onClick={() => setContactOpen(true)} className="btn-primary rounded-full whitespace-nowrap">
            Оставить заявку
          </button>
        </nav>

        <div className="md:hidden">
          <button className="text-foreground" onClick={() => setOpen(!open)} aria-label="Меню">
            {open ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
          </button>
        </div>
      </div>

      {open && (
        <nav className="md:hidden fixed inset-0 top-16 bg-background z-40 flex flex-col px-8 py-10 animate-fade-in">
          <div className="space-y-8">
            {sectionLinks.map((l) => (
              <button key={l.hash} onClick={() => go(l.hash)} className="block text-2xl font-bold text-foreground">
                {l.label}
              </button>
            ))}
            <Link to="/cases" onClick={() => setOpen(false)} className="block text-2xl font-bold text-foreground">
              Истории партнеров
            </Link>
          </div>

          <div className="mt-auto pt-8 border-t border-border">
            <div className="text-sm text-muted-foreground mb-2">Контакт</div>
            <div className="text-lg font-bold text-foreground">Дмитрий Астахов</div>
            <a href="tel:89233350610" className="mt-2 inline-block text-xl font-bold text-primary">
              8-923-335-06-10
            </a>
            <div className="mt-4">
              <SocialLinks imgSize="w-8 h-8" gap="gap-3" />
            </div>
            <button onClick={() => { setOpen(false); setContactOpen(true); }} className="btn-primary w-full mt-8 rounded-xl">
              Оставить заявку
            </button>
          </div>
        </nav>
      )}
    </header>
    <ContactDialog open={contactOpen} onOpenChange={setContactOpen} goalId="header_lead" />
    </>
  );
};

export default Header;