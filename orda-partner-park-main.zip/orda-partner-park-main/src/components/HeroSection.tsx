import { useState } from "react";
import ContactDialog from "@/components/ContactDialog";
import heroTruckBg from "@/assets/hero-truck-bg.png";
import heroMobileBg from "@/assets/hero-mobile-bg.jpg";

const accentText = "Но не в одиночку.";

const HeroSection = () => {
  const [dialogOpen, setDialogOpen] = useState(false);

  return (
    <section className="bg-background overflow-hidden">
      {/* Mobile: full-height background image with text overlay at top */}
      <div className="lg:hidden relative flex flex-col" style={{ minHeight: "100svh" }}>
        {/* Background image — full screen */}
        <img
          src={heroMobileBg}
          alt="Фура Орда Партнер Парк"
          className="absolute inset-0 w-full h-full object-cover object-bottom opacity-0"
          style={{ animation: "fade-in 0.6s ease 0.1s both" }}
          loading="eager"
        />
        {/* Gradient overlay only at top for text readability */}
        <div
          className="absolute inset-0 pointer-events-none"
          style={{
            background: "linear-gradient(to bottom, hsl(var(--background) / 0.88) 0%, hsl(var(--background) / 0.5) 28%, transparent 45%)",
          }}
        />
        {/* Text at top */}
        <div className="relative z-10 px-5 sm:px-8 pt-8">
          <h1
            className="font-bold text-foreground leading-[1.05] tracking-[-0.03em] opacity-0"
            style={{
              fontSize: "clamp(2.5rem, 9vw, 3.5rem)",
              animation: "swiss-reveal 0.6s var(--ease-out) 0.2s both",
            }}
          >
            Работай на&nbsp;себя.
          </h1>
          <div
            className="leading-[1.05] tracking-[-0.05em] font-bold text-primary"
            style={{ fontSize: "clamp(2.5rem, 9vw, 3.5rem)" }}
          >
            {accentText.split("").map((char, i) => (
              <span
                key={i}
                className="inline-block opacity-0"
                style={{
                  animation: `letter-up 0.4s var(--ease-out) ${0.5 + i * 0.03}s both`,
                }}
              >
                {char === " " ? "\u00A0" : char}
              </span>
            ))}
          </div>

          <p
            className="text-foreground font-medium mt-4 max-w-[280px] opacity-0"
            style={{ fontSize: "var(--type-md)", lineHeight: 1.5, animation: "swiss-reveal 0.6s var(--ease-out) 1.1s both" }}
          >
            Стабильные заказы для&nbsp;владельцев фур без&nbsp;поиска клиентов и&nbsp;бумаг
          </p>

          <div
            className="mt-5 opacity-0"
            style={{ animation: "swiss-reveal 0.6s var(--ease-out) 1.3s both" }}
          >
            <button onClick={() => setDialogOpen(true)} className="btn-primary rounded-xl">
              Стать партнером →
            </button>
          </div>
        </div>
      </div>

      {/* Desktop: full-width bg image with gradient */}
      <div
        className="hidden lg:block relative overflow-hidden"
        style={{ minHeight: "min(85vh, 700px)" }}
      >
        <img
          src={heroTruckBg}
          alt="Фура Орда Партнер Парк"
          className="absolute inset-0 w-full h-full object-cover object-right opacity-0"
          style={{ animation: "fade-in 0.8s ease 0.1s both" }}
          loading="eager"
        />
        <div
          className="absolute inset-0"
          style={{
            background: "linear-gradient(to right, hsl(var(--background) / 0.95) 25%, hsl(var(--background) / 0.7) 40%, hsl(var(--background) / 0.2) 60%, transparent 75%)",
          }}
        />
        <div className="relative z-10 container-landing px-5 sm:px-8 lg:px-12 flex items-center" style={{ minHeight: "min(85vh, 700px)" }}>
          <div className="max-w-xl py-28 lg:py-36">
            <h1
              className="font-bold text-foreground leading-[1.05] tracking-[-0.03em] opacity-0"
              style={{
                fontSize: "clamp(2.5rem, 5.5vw, 4rem)",
                animation: "swiss-reveal 0.6s var(--ease-out) 0.2s both",
              }}
            >
              Работай на&nbsp;себя.
            </h1>
            <div
              className="leading-[1.05] tracking-[-0.03em] font-bold text-primary"
              style={{ fontSize: "clamp(2.5rem, 5.5vw, 4rem)" }}
            >
              {accentText.split("").map((char, i) => (
                <span
                  key={i}
                  className="inline-block opacity-0"
                  style={{
                    animation: `letter-up 0.4s var(--ease-out) ${0.5 + i * 0.03}s both`,
                  }}
                >
                  {char === " " ? "\u00A0" : char}
                </span>
              ))}
            </div>

            <p
              className="text-foreground font-medium mt-6 max-w-md opacity-0"
              style={{ fontSize: "var(--type-md)", lineHeight: 1.5, animation: "swiss-reveal 0.6s var(--ease-out) 1.1s both" }}
            >
              Стабильные заказы для&nbsp;владельцев фур без&nbsp;поиска клиентов и&nbsp;бумаг
            </p>

            <div
              className="mt-10 opacity-0"
              style={{ animation: "swiss-reveal 0.6s var(--ease-out) 1.3s both" }}
            >
              <button onClick={() => setDialogOpen(true)} className="btn-primary rounded-xl">
                Стать партнером →
              </button>
            </div>
          </div>
        </div>
      </div>

      <ContactDialog open={dialogOpen} onOpenChange={setDialogOpen} title="Стать партнером" goalId="hero_partner" />
    </section>
  );
};

export default HeroSection;
