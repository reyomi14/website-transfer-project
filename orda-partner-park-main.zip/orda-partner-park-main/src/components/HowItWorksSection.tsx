import { useRef, useState, useEffect } from "react";
import { useScrollAnimation } from "@/hooks/useScrollAnimation";
import trucksFleet from "@/assets/trucks-fleet-branded.png";
import { ChevronLeft, ChevronRight, FileSignature, MapPin, ClipboardList, Truck, FileCheck, Banknote } from "lucide-react";

const steps = [
  { num: "01", title: "Подписываете договор", icon: FileSignature },
  { num: "02", title: "Выбираете направление", icon: MapPin },
  { num: "03", title: "Получаете заявки", icon: ClipboardList },
  { num: "04", title: "Выполняете рейс", icon: Truck },
  { num: "05", title: "Передаете документы", icon: FileCheck },
  { num: "06", title: "Получаете оплату", icon: Banknote },
];

const HowItWorksSection = () => {
  const { ref, isVisible } = useScrollAnimation();
  const scrollRef = useRef<HTMLDivElement>(null);
  const [activeIdx, setActiveIdx] = useState(0);

  const scrollToIdx = (idx: number) => {
    const el = scrollRef.current;
    if (!el) return;
    const card = el.children[idx] as HTMLElement;
    if (card) {
      el.scrollTo({ left: card.offsetLeft - 16, behavior: "smooth" });
      setActiveIdx(idx);
    }
  };

  useEffect(() => {
    const el = scrollRef.current;
    if (!el) return;
    const onScroll = () => {
      const children = Array.from(el.children) as HTMLElement[];
      let closest = 0;
      let minDist = Infinity;
      children.forEach((child, i) => {
        const dist = Math.abs(child.offsetLeft - el.scrollLeft - 16);
        if (dist < minDist) { minDist = dist; closest = i; }
      });
      setActiveIdx(closest);
    };
    el.addEventListener("scroll", onScroll, { passive: true });
    return () => el.removeEventListener("scroll", onScroll);
  }, []);

  return (
    <section id="how" className="section-padding bg-background">
      <div className="container-landing" ref={ref}>
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 lg:gap-16">
          <div className="lg:col-span-4">
            <span className={`label-swiss text-muted-foreground block mb-4 transition-all duration-600 ${isVisible ? "opacity-100" : "opacity-0"}`}>
              Процесс
            </span>
            <h2 className={`section-heading text-foreground transition-all duration-600 delay-100 ${isVisible ? "opacity-100 translate-y-0" : "opacity-0 translate-y-5"}`}>
              Простая логика{" "}
              <span className="text-primary">партнерства</span>
            </h2>
            <div className={`mt-10 hidden lg:block transition-all duration-600 delay-300 ${isVisible ? "opacity-100 translate-y-0" : "opacity-0 translate-y-5"}`}>
              <img src={trucksFleet} alt="Автопарк" className="w-full object-cover rounded-2xl" loading="lazy" />
            </div>
          </div>

          {/* Desktop: vertical list */}
          <div className="hidden lg:block lg:col-span-7 lg:col-start-6">
            <div className="space-y-2">
              {steps.map((step, i) => {
                const Icon = step.icon;
                return (
                  <div
                    key={step.num}
                    className={`bg-card rounded-xl flex items-center gap-5 px-6 py-5 transition-all duration-500 ${isVisible ? "opacity-100 translate-y-0" : "opacity-0 translate-y-5"}`}
                    style={{ transitionDelay: isVisible ? `${200 + i * 70}ms` : "0ms" }}
                  >
                    <span className="text-accent-warm font-bold shrink-0" style={{ fontSize: "var(--type-lg)" }}>
                      {step.num}
                    </span>
                    <Icon className="w-5 h-5 text-muted-foreground shrink-0" strokeWidth={1.5} />
                    <h3 className="text-foreground font-bold text-base">
                      {step.title}
                    </h3>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Mobile: horizontal slider — taller cards, bigger text */}
          <div className="lg:hidden col-span-1">
            <div
              ref={scrollRef}
              className="flex gap-3 overflow-x-auto scrollbar-hide snap-x snap-mandatory -mx-5 px-5 pb-4"
            >
              {steps.map((step, i) => {
                const Icon = step.icon;
                return (
                  <div
                    key={step.num}
                    className={`bg-card rounded-2xl flex flex-col justify-between p-6 min-w-[200px] min-h-[160px] snap-start shrink-0 transition-all duration-500 ${isVisible ? "opacity-100 translate-y-0" : "opacity-0 translate-y-5"}`}
                    style={{ transitionDelay: isVisible ? `${200 + i * 70}ms` : "0ms" }}
                  >
                    <div className="flex items-center gap-3">
                      <span className="text-accent-warm font-bold" style={{ fontSize: "var(--type-xl)" }}>
                        {step.num}
                      </span>
                      <Icon className="w-5 h-5 text-muted-foreground" strokeWidth={1.5} />
                    </div>
                    <h3 className="text-foreground font-bold text-base mt-4">
                      {step.title}
                    </h3>
                  </div>
                );
              })}
            </div>

            {/* Dots + arrows */}
            <div className="flex items-center justify-center gap-4 mt-4">
              <button onClick={() => scrollToIdx(Math.max(0, activeIdx - 1))} className="w-10 h-10 rounded-full bg-card flex items-center justify-center text-muted-foreground hover:text-foreground transition-colors" aria-label="Назад">
                <ChevronLeft className="w-6 h-6" />
              </button>
              <div className="flex gap-1.5">
                {steps.map((_, i) => (
                  <button
                    key={i}
                    onClick={() => scrollToIdx(i)}
                    className={`h-2 rounded-full transition-all ${i === activeIdx ? "bg-primary w-5" : "bg-border w-2"}`}
                    aria-label={`Шаг ${i + 1}`}
                  />
                ))}
              </div>
              <button onClick={() => scrollToIdx(Math.min(steps.length - 1, activeIdx + 1))} className="w-10 h-10 rounded-full bg-card flex items-center justify-center text-muted-foreground hover:text-foreground transition-colors" aria-label="Вперед">
                <ChevronRight className="w-6 h-6" />
              </button>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default HowItWorksSection;
