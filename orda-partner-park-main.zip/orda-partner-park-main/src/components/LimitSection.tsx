import { useScrollAnimation } from "@/hooks/useScrollAnimation";

const LimitSection = () => {
  const { ref, isVisible } = useScrollAnimation();

  return (
    <section className="section-padding bg-foreground text-background">
      <div className="container-landing max-w-[960px]" ref={ref}>
        <div className={`transition-all duration-600 ${isVisible ? "opacity-100 translate-y-0" : "opacity-0 translate-y-5"}`}>
          <span className="text-sm font-semibold text-accent-warm block mb-6">Ограничение</span>
          <p className="font-bold text-background leading-[1.15] tracking-[-0.02em]" style={{ fontSize: "clamp(1.5rem, 4vw, var(--type-2xl))" }}>
            Мы&nbsp;принимаем ограниченное количество сцепок в&nbsp;каждом регионе, чтобы сохранять&nbsp;экономику
          </p>
        </div>
      </div>
    </section>
  );
};

export default LimitSection;
