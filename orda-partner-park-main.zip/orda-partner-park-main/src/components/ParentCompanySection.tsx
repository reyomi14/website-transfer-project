import { useScrollAnimation } from "@/hooks/useScrollAnimation";

const stats = [
  { value: "700+", label: "Автомобилей" },
  { value: "1 600+", label: "Сотрудников" },
  { value: "11", label: "Лет на рынке" },
  { value: "30 000", label: "Населенных пунктов" },
];

const ParentCompanySection = () => {
  const { ref, isVisible } = useScrollAnimation();

  return (
    <section className="px-5 sm:px-8 lg:px-12 py-12 sm:py-16 lg:py-20 bg-background">
      <div className="container-landing" ref={ref}>
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 lg:gap-16">
          <div className="lg:col-span-5">
            <span className={`label-swiss text-muted-foreground block mb-3 transition-all duration-600 ${isVisible ? "opacity-100" : "opacity-0"}`}>
              Материнская компания
            </span>
            <h3 className={`text-foreground font-bold leading-[1.2] transition-all duration-600 delay-100 ${isVisible ? "opacity-100 translate-y-0" : "opacity-0 translate-y-5"}`}
              style={{ fontSize: "var(--type-lg)" }}>
              Орда Партнер Парк: проект{" "}
              <span className="text-primary">ТК&nbsp;«Орда»</span>
            </h3>
          </div>

          <div className={`lg:col-span-6 lg:col-start-7 transition-all duration-600 delay-200 ${isVisible ? "opacity-100 translate-y-0" : "opacity-0 translate-y-5"}`}>
            <p className="text-muted-foreground text-sm leading-relaxed mb-8">
              Транспортная компания «Орда» работает с&nbsp;2013&nbsp;года. Собственный автопарк
              из&nbsp;700+ единиц техники, более 1&nbsp;600 сотрудников, доставка в&nbsp;30&nbsp;000
              населенных пунктов России
            </p>

            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
              {stats.map((s, i) => (
                <div key={i} className="bg-card rounded-xl p-5 text-center">
                  <span className="text-accent-warm font-bold block leading-none mb-2" style={{ fontSize: "var(--type-md)" }}>{s.value}</span>
                  <span className="text-xs text-muted-foreground">{s.label}</span>
                </div>
              ))}
            </div>

          </div>
        </div>
      </div>
    </section>
  );
};

export default ParentCompanySection;
