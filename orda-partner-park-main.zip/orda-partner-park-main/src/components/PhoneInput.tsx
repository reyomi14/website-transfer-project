import { forwardRef, useImperativeHandle, useRef, useState } from "react";
import { formatRussianPhone } from "@/lib/phoneMask";

type PhoneInputProps = Omit<React.InputHTMLAttributes<HTMLInputElement>, "type" | "value" | "defaultValue" | "onChange">;

const PhoneInput = forwardRef<HTMLInputElement, PhoneInputProps>(({ className = "", style, onFocus, onBlur, onKeyDown, ...props }, forwardedRef) => {
  const inputRef = useRef<HTMLInputElement>(null);
  const [value, setValue] = useState("");

  useImperativeHandle(forwardedRef, () => inputRef.current as HTMLInputElement);

  const moveCaretToEnd = () => {
    const input = inputRef.current;
    if (!input) return;
    window.requestAnimationFrame(() => {
      if (document.activeElement === input) {
        input.setSelectionRange(input.value.length, input.value.length);
      }
    });
  };

  return (
    <input
      {...props}
      ref={inputRef}
      type="tel"
      inputMode="tel"
      value={value}
      placeholder="+7 (999) 123-45-67"
      onFocus={(event) => {
        if (!value) {
          setValue("+7");
        }
        onFocus?.(event);
        moveCaretToEnd();
      }}
      onBlur={(event) => {
        if (event.currentTarget.value === "+7") {
          setValue("");
        }
        onBlur?.(event);
      }}
      onChange={(event) => {
        setValue(formatRussianPhone(event.currentTarget.value));
        moveCaretToEnd();
      }}
      onKeyDown={(event) => {
        const { selectionStart, selectionEnd } = event.currentTarget;
        const isDeletingPrefix =
          (event.key === "Backspace" && selectionStart !== null && selectionStart <= 2 && selectionEnd !== null && selectionEnd <= 2) ||
          (event.key === "Delete" && selectionStart !== null && selectionStart < 2);

        if (isDeletingPrefix) {
          event.preventDefault();
          moveCaretToEnd();
        }

        onKeyDown?.(event);
      }}
      className={`h-14 w-full min-w-0 leading-none ${className}`}
      style={{
        ...style,
        caretColor: "hsl(var(--foreground))",
      }}
    />
  );
});

PhoneInput.displayName = "PhoneInput";

export default PhoneInput;