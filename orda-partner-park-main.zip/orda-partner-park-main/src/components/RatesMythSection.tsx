import { useScrollAnimation } from "@/hooks/useScrollAnimation";

const benefits = [
  {
    title: "Ставка считается на круг",
    detail: "Москва–Красноярск–Москва рефрижератор: 85,97 руб./км на 8 200 км. Выручка за круг 705 тыс. руб.",
  },
  {
    title: "Простой не более 2 дней",
    detail: "270+ клиентов в базе. Подбираем заявки так, чтобы минимизировать время ожидания",
  },
  {
    title: "Оплата гарантирована",
    detail: "Все риски по оплатам на нас: вы получаете деньги по графику. Аванс доступен со второго месяца",
  },
];

const RatesMythSection = () => {
  const { ref, isVisible } = useScrollAnimation();

  return (
    <section className="section-padding bg-background">
      <div className="container-landing" ref={ref}>
        <span className={`label-swiss text-muted-foreground block mb-4 transition-all duration-600 ${isVisible ? "opacity-100" : "opacity-0"}`}>
          Преимущества
        </span>
        <h2 className={`section-heading text-foreground mb-14 transition-all duration-600 delay-100 ${isVisible ? "opacity-100 translate-y-0" : "opacity-0 translate-y-5"}`}>
          <span className="text-primary">Почему партнерство,</span>{" "}
          <br className="md:hidden" />а&nbsp;не&nbsp;биржа
        </h2>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
          {benefits.map((b, i) => (
            <div
              key={i}
              className={`bg-card rounded-2xl p-8 transition-all duration-500 ${isVisible ? "opacity-100 translate-y-0" : "opacity-0 translate-y-5"}`}
              style={{ transitionDelay: isVisible ? `${150 + i * 70}ms` : "0ms" }}
            >
              <span className="text-accent-warm font-bold block mb-4" style={{ fontSize: "var(--type-xl)" }}>
                {String(i + 1).padStart(2, "0")}
              </span>
              <h3 className="text-foreground font-bold mb-3" style={{ fontSize: "var(--type-md)" }}>{b.title}</h3>
              <p className="text-muted-foreground text-sm leading-relaxed">{b.detail}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default RatesMythSection;