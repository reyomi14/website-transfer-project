import { useState } from "react";
import { useScrollAnimation } from "@/hooks/useScrollAnimation";
import ContactDialog from "@/components/ContactDialog";
import { Check, Circle } from "lucide-react";

const weHandle = [
  "Поиск заказов и\u00A0клиентов",
  "Проверка заказчиков собственной СБ",
  "Формирование документов",
  "Разработка маршрутов",
  "Логистическое сопровождение",
  "Информирование заказчика",
  "Юридическая помощь",
  "Консультации в\u00A0ЧП",
  "Страховки и\u00A0пропуска",
];

const partnerHandles = [
  "Контроль за\u00A0водителями",
  "Обслуживание авто",
  "Тахограф, ГЛОНАСС, Платон",
  "Своевременная доставка",
  "Заполнение документов",
];

const ResponsibilitiesSection = () => {
  const { ref, isVisible } = useScrollAnimation();
  const [dialogOpen, setDialogOpen] = useState(false);

  return (
    <section id="responsibilities" className="section-padding bg-background">
      <div className="container-landing" ref={ref}>
        <h2 className={`section-heading text-foreground mb-4 transition-all duration-600 ${isVisible ? "opacity-100 translate-y-0" : "opacity-0 translate-y-5"}`}>
          Зоны ответственности
        </h2>

        <div className={`grid grid-cols-1 md:grid-cols-2 gap-4 mb-12 transition-all duration-500 delay-200 ${isVisible ? "opacity-100 translate-y-0" : "opacity-0 translate-y-5"}`}>
          <div className="bg-primary rounded-2xl p-8">
            <div className="flex items-center gap-3 mb-6">
              <div className="w-8 h-8 rounded-full bg-primary-foreground/20 flex items-center justify-center">
                <Check className="w-4 h-4 text-primary-foreground" />
              </div>
              <h3 className="font-bold text-primary-foreground text-base">Мы берем на себя</h3>
            </div>
            {weHandle.map((item, i) => (
              <div key={i} className="flex items-start gap-3 py-3 border-b border-primary-foreground/15 last:border-b-0">
                <span className="text-primary-foreground/50 font-bold text-xs tabular-nums pt-1 shrink-0">{String(i + 1).padStart(2, "0")}</span>
                <span className="text-sm text-primary-foreground font-medium">{item}</span>
              </div>
            ))}
          </div>

          <div className="bg-card rounded-2xl p-8">
            <div className="flex items-center gap-3 mb-6">
              <div className="w-8 h-8 rounded-full bg-muted flex items-center justify-center">
                <Circle className="w-4 h-4 text-muted-foreground" />
              </div>
              <h3 className="font-bold text-foreground text-base">Остается на партнере</h3>
            </div>
            {partnerHandles.map((item, i) => (
              <div key={i} className="flex items-start gap-3 py-3 border-b border-border last:border-b-0">
                <span className="text-muted-foreground font-bold text-xs tabular-nums pt-1 shrink-0">{String(i + 1).padStart(2, "0")}</span>
                <span className="text-sm text-foreground">{item}</span>
              </div>
            ))}
          </div>
        </div>

        <button onClick={() => setDialogOpen(true)} className="btn-primary rounded-xl">
          Обсудить условия →
        </button>
      </div>
      <ContactDialog open={dialogOpen} onOpenChange={setDialogOpen} title="Обсудить условия партнерства" goalId="responsibilities_discuss" />
    </section>
  );
};

export default ResponsibilitiesSection;
