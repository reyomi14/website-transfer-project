import { useLayoutEffect, useRef } from "react";
import { useLocation, useNavigationType } from "react-router-dom";

const ScrollToTop = () => {
  const location = useLocation();
  const navType = useNavigationType();
  const scrollPositions = useRef<Record<string, number>>({});

  useLayoutEffect(() => {
    if ("scrollRestoration" in window.history) {
      window.history.scrollRestoration = "manual";
    }
  }, []);

  useLayoutEffect(() => {
    const currentKey = location.key;

    if (navType === "POP") {
      const saved = scrollPositions.current[currentKey] ?? 0;
      window.scrollTo(0, saved);
      return () => {
        scrollPositions.current[currentKey] = window.scrollY;
      };
    }

    if (location.hash) {
      const el = document.querySelector(location.hash);
      if (el) {
        const headerHeight = 64;
        const y = el.getBoundingClientRect().top + window.scrollY - headerHeight;
        window.scrollTo(0, y);
      }
    } else {
      window.scrollTo(0, 0);
    }

    return () => {
      scrollPositions.current[currentKey] = window.scrollY;
    };
  }, [location.key, location.hash, navType]);

  return null;
};

export default ScrollToTop;
