import { useState } from "react";
import { useScrollAnimation } from "@/hooks/useScrollAnimation";
import ContactDialog from "@/components/ContactDialog";
import { Fuel, FileCheck, Wrench, Shield, LifeBuoy, Route, UserCheck } from "lucide-react";

const items = [
  { icon: Fuel, title: "Спецусловия по\u00A0топливу", desc: "Скидки до\u00A020% на\u00A0ДТ через партнерские АЗС" },
  { icon: FileCheck, title: "Полный документооборот", desc: "ЭТрН, ТТН, договоры, акты сверки" },
  { icon: Wrench, title: "Запчасти и\u00A0ТО", desc: "Партнерские цены по\u00A0всей России" },
  { icon: Shield, title: "Лизинг и\u00A0страхование", desc: "Содействие в\u00A0оформлении" },
  { icon: LifeBuoy, title: "Помощь в\u00A0ЧП", desc: "Консультации при\u00A0ДТП и\u00A0задержках" },
  { icon: Route, title: "Логистика 24/7", desc: "Маршруты и\u00A0решение вопросов в\u00A0рейсе" },
  { icon: UserCheck, title: "Рекомендации по\u00A0повышению прибыли", desc: "Персональный менеджер поможет вам зарабатывать больше" },
];

const ServicesSection = () => {
  const { ref, isVisible } = useScrollAnimation();
  const [dialogOpen, setDialogOpen] = useState(false);

  return (
    <section className="section-padding bg-background">
      <div className="container-landing" ref={ref}>
        <span className={`label-swiss text-muted-foreground block mb-4 transition-all duration-600 ${isVisible ? "opacity-100" : "opacity-0"}`}>
          Сервисы
        </span>
        <h2 className={`section-heading text-foreground mb-14 transition-all duration-600 delay-100 ${isVisible ? "opacity-100 translate-y-0" : "opacity-0 translate-y-5"}`}>
          Условия{" "}
          <span className="text-primary">как у крупной компании</span>
        </h2>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {items.map((item, i) => {
            const Icon = item.icon;
            return (
              <div
                key={i}
                className={`bg-card rounded-2xl p-7 flex items-start gap-5 transition-all duration-500 ${isVisible ? "opacity-100 translate-y-0" : "opacity-0 translate-y-5"}`}
                style={{ transitionDelay: isVisible ? `${150 + i * 50}ms` : "0ms" }}
              >
                <div className="w-10 h-10 bg-primary/10 rounded-lg flex items-center justify-center shrink-0">
                  <Icon className="w-5 h-5 text-primary" strokeWidth={1.5} />
                </div>
                <div>
                  <h3 className="text-foreground font-bold mb-0.5 text-sm">{item.title}</h3>
                  <p className="text-muted-foreground text-sm">{item.desc}</p>
                </div>
              </div>
            );
          })}
        </div>

        <div className="mt-12">
          <button onClick={() => setDialogOpen(true)} className="btn-secondary rounded-xl">
            Узнать подробнее →
          </button>
        </div>
      </div>
      <ContactDialog open={dialogOpen} onOpenChange={setDialogOpen} title="Узнать подробнее об условиях" goalId="services_details" />
    </section>
  );
};

export default ServicesSection;