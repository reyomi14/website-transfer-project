import maxIcon from "@/assets/max-icon.png";
import telegramIcon from "@/assets/telegram-icon.png";

interface SocialLinksProps {
  iconSize?: string;
  imgSize?: string;
  colorClass?: string;
  hoverClass?: string;
  gap?: string;
}

const SocialLinks = ({
  imgSize = "w-7 h-7",
  gap = "gap-3",
}: SocialLinksProps) => (
  <div className={`flex items-center ${gap}`}>
    <a
      href="https://t.me/DmitryAstakhov09"
      target="_blank"
      rel="noopener noreferrer"
      className="transition-opacity hover:opacity-80"
      title="Telegram"
    >
      <img src={telegramIcon} alt="Telegram" className={`${imgSize} rounded-full`} />
    </a>
    <a
      href="https://max.ru/u/f9LHodD0cOJZx-FA52BoMaW2kSwIZQbDi43CDorqv7NkzdJZKBn-3g0qlXI"
      target="_blank"
      rel="noopener noreferrer"
      className="transition-opacity hover:opacity-80"
      title="MAX"
    >
      <img src={maxIcon} alt="MAX" className={`${imgSize} rounded-lg`} />
    </a>
  </div>
);

export { SocialLinks };
export default SocialLinks;
