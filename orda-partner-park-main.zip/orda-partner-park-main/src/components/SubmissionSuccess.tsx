import dmitriy from "@/assets/dmitriy.png";

interface SubmissionSuccessProps {
  variant?: "card" | "centered";
  className?: string;
}

const SubmissionSuccess = ({ variant = "centered", className = "" }: SubmissionSuccessProps) => {
  if (variant === "card") {
    return (
      <div className={`bg-background rounded-2xl p-4 sm:p-5 flex items-center gap-4 ${className}`}>
        <img
          src={dmitriy}
          alt="Дмитрий"
          loading="lazy"
          className="w-14 h-14 sm:w-16 sm:h-16 rounded-full object-cover shrink-0 border-2 border-primary/20"
        />
        <div className="min-w-0">
          <div className="text-foreground font-bold text-sm sm:text-base leading-tight">
            Заявка отправлена
          </div>
          <p className="text-muted-foreground text-xs sm:text-sm leading-snug mt-1">
            Дмитрий свяжется с вами в течение 30 минут
          </p>
        </div>
      </div>
    );
  }

  return (
    <div className={`py-4 space-y-3 text-center ${className}`}>
      <img
        src={dmitriy}
        alt="Дмитрий"
        loading="lazy"
        className="w-20 h-20 rounded-full object-cover mx-auto border-2 border-primary/20"
      />
      <h3 className="font-bold text-foreground" style={{ fontSize: "var(--type-md)" }}>
        Заявка отправлена
      </h3>
      <p className="text-muted-foreground text-sm">
        Дмитрий свяжется с вами в течение 30 минут
      </p>
    </div>
  );
};

export default SubmissionSuccess;
