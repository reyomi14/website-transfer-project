import { useYandexMetrikaHit } from "@/hooks/useYandexMetrika";

export function YandexMetrikaHit() {
  useYandexMetrikaHit();
  return null;
}
