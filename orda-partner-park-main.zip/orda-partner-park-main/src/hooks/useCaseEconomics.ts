import { useState, useEffect } from "react";

export interface CaseEconomics {
  mileage: string;
  rate: string;
  revenue: string;
  expenses: string;
  profit: string;
  expensesNote: string;
}

const SHEET_ID = "1rvAKE4FtGTjR-R3eT18Y3BvkpESvD5M-abaEW_VAHUY";

function splitCSVLine(line: string): string[] {
  const cols: string[] = [];
  let current = "";
  let inQuotes = false;
  for (const ch of line) {
    if (ch === '"') { inQuotes = !inQuotes; continue; }
    if (ch === ',' && !inQuotes) { cols.push(current.trim()); current = ""; continue; }
    current += ch;
  }
  cols.push(current.trim());
  return cols;
}

export function useCaseEconomics(): Record<string, CaseEconomics> {
  const [data, setData] = useState<Record<string, CaseEconomics>>({});

  useEffect(() => {
    const url = `https://docs.google.com/spreadsheets/d/${SHEET_ID}/gviz/tq?tqx=out:csv`;

    fetch(url)
      .then(res => {
        if (!res.ok) throw new Error("Failed");
        return res.text();
      })
      .then(csv => {
        const lines = csv.trim().split("\n");
        if (lines.length < 2) return;

        const headers = splitCSVLine(lines[0]);
        const idIdx = headers.findIndex(h => h.toLowerCase() === "id");
        const mileageIdx = headers.findIndex(h => h.toLowerCase() === "mileage");
        const rateIdx = headers.findIndex(h => h.toLowerCase() === "rate");
        const revenueIdx = headers.findIndex(h => h.toLowerCase() === "revenue");
        const expensesIdx = headers.findIndex(h => h.toLowerCase() === "expenses");
        const profitIdx = headers.findIndex(h => h.toLowerCase() === "profit");
        const noteIdx = headers.findIndex(h => h.toLowerCase() === "expensesnote");

        if (idIdx === -1) return;

        const result: Record<string, CaseEconomics> = {};
        for (let i = 1; i < lines.length; i++) {
          const cols = splitCSVLine(lines[i]);
          const id = cols[idIdx];
          if (!id) continue;
          result[id] = {
            mileage: cols[mileageIdx] || "",
            rate: cols[rateIdx] || "",
            revenue: cols[revenueIdx] || "",
            expenses: cols[expensesIdx] || "",
            profit: cols[profitIdx] || "",
            expensesNote: cols[noteIdx] || "",
          };
        }
        setData(result);
      })
      .catch(() => {});
  }, []);

  return data;
}
