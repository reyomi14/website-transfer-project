import { useState, useEffect } from "react";

export interface RouteData {
  route: string;
  km: string;
  profitRef: string;
  profitTent: string | null;
}

const FALLBACK_ROUTES: RouteData[] = [
  { route: "Запад – Сибирь – Запад", km: "8 200 км", profitRef: "310 000", profitTent: "240 000" },
  { route: "Сибирь – Восток – Сибирь", km: "10 000 км", profitRef: "315 000", profitTent: null },
  { route: "Запад – Восток – Запад", km: "18 200 км", profitRef: "650 000", profitTent: "530 000" },
];

const SHEET_ID = "1QSnJ_oF8xX73MKxKS-JPz1c7T9TVOzpPAzMeBFiqTFU";

function splitCSVLine(line: string): string[] {
  const cols: string[] = [];
  let current = "";
  let inQuotes = false;
  for (const ch of line) {
    if (ch === '"') { inQuotes = !inQuotes; continue; }
    if (ch === ',' && !inQuotes) { cols.push(current.trim()); current = ""; continue; }
    current += ch;
  }
  cols.push(current.trim());
  return cols;
}

function parseCSV(csv: string): RouteData[] {
  const lines = csv.trim().split("\n");
  if (lines.length < 2) return [];

  // Parse headers to find column indices by name
  const headers = splitCSVLine(lines[0]).map(h => h.toLowerCase().trim());
  
  const routeIdx = headers.findIndex(h => h.includes("направлен"));
  const kmIdx = headers.findIndex(h => h.includes("км") || h.includes("km"));
  const refIdx = headers.findIndex(h => h.includes("реф") || h.includes("ref"));
  const tentIdx = headers.findIndex(h => h.includes("тент") || h.includes("tent"));

  if (routeIdx === -1) return [];

  return lines.slice(1).filter(line => line.trim()).map(line => {
    const cols = splitCSVLine(line);
    const tent = tentIdx !== -1 ? cols[tentIdx] : undefined;
    return {
      route: routeIdx !== -1 ? (cols[routeIdx] || "") : "",
      km: kmIdx !== -1 ? (cols[kmIdx] || "") : "",
      profitRef: refIdx !== -1 ? (cols[refIdx] || "") : "",
      profitTent: tent && tent !== "" && tent !== "-" && tent !== "0" ? tent : null,
    };
  }).filter(r => r.route);
}

export function useGoogleSheet() {
  const [routes, setRoutes] = useState<RouteData[]>(FALLBACK_ROUTES);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    if (!SHEET_ID) return;

    setLoading(true);
    const url = `https://docs.google.com/spreadsheets/d/${SHEET_ID}/export?format=csv&gid=0`;

    fetch(url)
      .then(res => {
        if (!res.ok) throw new Error("Failed to fetch");
        return res.text();
      })
      .then(csv => {
        const parsed = parseCSV(csv);
        if (parsed.length > 0) {
          const shuffled = [...parsed].sort(() => Math.random() - 0.5);
          setRoutes(shuffled.slice(0, 3));
        }
      })
      .catch(() => {})
      .finally(() => setLoading(false));
  }, []);

  return { routes, loading };
}
