const UTM_KEYS = ["utm_source", "utm_medium", "utm_campaign", "utm_term", "utm_content"] as const;
const STORAGE_KEY = "utm_params";

export type UtmParams = Partial<Record<(typeof UTM_KEYS)[number], string>>;

/** Call once on app mount to persist UTM params from the landing URL. */
export function captureUtm() {
  const params = new URLSearchParams(window.location.search);
  const utm: UtmParams = {};
  let found = false;
  for (const key of UTM_KEYS) {
    const val = params.get(key);
    if (val) {
      utm[key] = val;
      found = true;
    }
  }
  if (found) {
    sessionStorage.setItem(STORAGE_KEY, JSON.stringify(utm));
  }
}

/** Return saved UTM params (empty object if none). */
export function getUtm(): UtmParams {
  try {
    return JSON.parse(sessionStorage.getItem(STORAGE_KEY) || "{}");
  } catch {
    return {};
  }
}

export function formatUtm(utm: UtmParams): string {
  const parts: string[] = [];
  if (utm.utm_source) parts.push(`source: ${utm.utm_source}`);
  if (utm.utm_medium) parts.push(`medium: ${utm.utm_medium}`);
  if (utm.utm_campaign) parts.push(`campaign: ${utm.utm_campaign}`);
  if (utm.utm_term) parts.push(`term: ${utm.utm_term}`);
  if (utm.utm_content) parts.push(`content: ${utm.utm_content}`);
  return parts.length ? parts.join(" / ") : "";
}
