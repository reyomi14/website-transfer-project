import { useEffect } from "react";
import { useLocation } from "react-router-dom";

declare global {
  interface Window {
    ym?: (id: number, action: string, ...args: unknown[]) => void;
  }
}

const YM_ID = 108298525;
const sentGoals = new Set<string>();

/** Трекает SPA-переходы между страницами */
export function useYandexMetrikaHit() {
  const location = useLocation();

  useEffect(() => {
    const url = location.pathname + location.search + location.hash;
    window.ym?.(YM_ID, "hit", url);
  }, [location]);
}

/** Отправляет цель при первом взаимодействии с формой */
export function trackFormInteraction(target: string) {
  if (sentGoals.has(target)) return;

  sentGoals.add(target);
  window.ym?.(YM_ID, "reachGoal", target);
}

/** Отправляет цель (reachGoal) в Метрику */
export function ymGoal(target: string, params?: Record<string, unknown>) {
  window.ym?.(YM_ID, "reachGoal", target, params);
}
