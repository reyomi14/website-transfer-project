export const formatRussianPhone = (value: string) => {
  const digits = value.replace(/\D/g, "").replace(/^8/, "7").slice(0, 11);
  const normalized = digits.startsWith("7") ? digits : `7${digits}`;
  const rest = normalized.slice(1);

  const parts = ["+7"];
  if (rest.length > 0) parts.push(` (${rest.slice(0, 3)}`);
  if (rest.length >= 3) parts[parts.length - 1] += ")";
  if (rest.length > 3) parts.push(` ${rest.slice(3, 6)}`);
  if (rest.length > 6) parts.push(`-${rest.slice(6, 8)}`);
  if (rest.length > 8) parts.push(`-${rest.slice(8, 10)}`);

  return parts.join("");
};

export const handlePhoneInput = (event: React.FormEvent<HTMLInputElement>) => {
  const input = event.currentTarget;
  input.value = formatRussianPhone(input.value);
  input.setSelectionRange(input.value.length, input.value.length);
};

export const handlePhoneFocus = (event: React.FocusEvent<HTMLInputElement>) => {
  const input = event.currentTarget;
  if (!input.value || input.value === "+") {
    input.value = "+7";
  }
  window.setTimeout(() => {
    if (document.activeElement === input) {
      input.setSelectionRange(input.value.length, input.value.length);
    }
  }, 0);
};

export const handlePhoneKeyDown = (event: React.KeyboardEvent<HTMLInputElement>) => {
  const { selectionStart, selectionEnd, value } = event.currentTarget;
  const isDeletingPrefix =
    (event.key === "Backspace" && selectionStart !== null && selectionStart <= 2 && selectionEnd !== null && selectionEnd <= 2) ||
    (event.key === "Delete" && selectionStart !== null && selectionStart < 2);

  if (value.startsWith("+7") && isDeletingPrefix) {
    event.preventDefault();
    event.currentTarget.setSelectionRange(value.length, value.length);
  }
};