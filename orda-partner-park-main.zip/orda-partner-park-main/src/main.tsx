import { createRoot } from "react-dom/client";
import App from "./App.tsx";
import "./index.css";
import { captureUtm } from "./hooks/useUtm";

captureUtm();
createRoot(document.getElementById("root")!).render(<App />);
