import { ArrowLeft, Truck, User, Quote } from "lucide-react";
import { Link, useNavigate, useParams } from "react-router-dom";
import { useCaseEconomics, CaseEconomics } from "@/hooks/useCaseEconomics";
import bardokinImg from "@/assets/bardokin.png";
import kuvaldinImg from "@/assets/kuvaldin.png";
import zinovievImg from "@/assets/zinoviev.png";

const avatars: Record<string, string> = {
  zinoviev: zinovievImg,
  kuvaldin: kuvaldinImg,
  bardokin: bardokinImg,
};

const cases = [
  {
    id: "zinoviev",
    type: "Партнер с несколькими сцепками",
    name: "Зиновьев Андрей",
    entity: "ООО «Зима»",
    trucks: "3 сцепки",
    truckDetail: "Седельные тягачи 2024 г/в + полуприцепы шторные ORTHAUS 2024 г/в",
    mode: "Две на экспрессе, одна на стандарте",
    background:
      "Был свой бизнес, не связанный с грузоперевозками. Имел опыт управления водителями и знания по эксплуатации грузовой техники.",
    goal: "Приобрести несколько сцепок и запустить полноценный бизнес по крупнотоннажным грузоперевозкам.",
    story:
      "В проект зашел в августе 2025 года, приобрел в лизинг три новые сцепки. В сентябре 2025 ТС вышли в первые рейсы. На данный момент партнер находится в проекте ПП, ТС работают под контролем и сопровождением Орды.",
    review:
      "Я долго искал формат, где можно запустить грузоперевозки, не разбираясь во всём самому. Орда помогла с лизингом, дала заказы с первого дня и ведёт все документы. Для меня это идеальная модель — я занимаюсь парком, а заказы и бумаги на них.",
    economics: {
      mileage: "60 729 км",
      rate: "76,01 руб./км",
      revenue: "4 615 883 ₽",
      expenses: "3 662 560 ₽",
      profit: "953 323 ₽",
      expensesNote: "ГСМ, ТО, Ремонт, страхование, Платон, платные дороги, зарплата водителей",
    },
  },
  {
    id: "kuvaldin",
    type: "ИП-водитель",
    name: "Кувалдин Алексей",
    entity: "ИП",
    trucks: "1 сцепка",
    truckDetail: "Седельный тягач Scania R440 2019 г/в + полуприцеп рефрижераторный KRONE SD 2017 г/в",
    mode: "На стандарте",
    background:
      "Работал водителем-дальнобойщиком. Большой опыт в управлении седельными тягачами.",
    goal: "Приобрести собственную сцепку и работать на себя.",
    story:
      "В проект зашел в мае 2025 года. Орда подобрала для него сцепку с пробегом и оформила лизинг. В конце мая 2025 вышел в первый рейс. Успешно закрывает финансовые обязательства, постепенно выкупает сцепку.",
    review:
      "Я хотел уйти из найма и работать на себя, но боялся, что не потяну один. Орда помогла купить сцепку, дала заказы и сопровождает в каждом рейсе. Теперь я зарабатываю не меньше, чем когда работал водителем, но это мой бизнес.",
    economics: {
      mileage: "16 425 км",
      rate: "80,23 руб./км",
      revenue: "1 317 778 ₽",
      expenses: "688 134 ₽",
      profit: "629 644 ₽",
      expensesNote: "ГСМ, ТО, Ремонт, страхование, Платон, платные дороги",
    },
  },
  {
    id: "bardokin",
    type: "ИП-водитель",
    name: "Бардокин Денис",
    entity: "ИП",
    trucks: "1 сцепка",
    truckDetail: "Седельный тягач FAW J7 2023 г/в + полуприцеп рефрижераторный KRONE SD 2017 г/в",
    mode: "На стандарте",
    background:
      "Работал водителем-дальнобойщиком. Большой опыт в управлении седельными тягачами.",
    goal: "Приобрести собственную сцепку и работать на себя.",
    story:
      "В проект зашел в сентябре 2025 года. Орда подобрала для него сцепку с пробегом и оформила лизинг. Успешно закрывает финансовые обязательства, постепенно выкупает сцепку и получает чистый доход.",
    review:
      "Мне нравится, что Орда берёт на себя всю головную боль с заказчиками и документами. Я просто выхожу в рейс, зная, что загрузка будет, оплата придёт вовремя, а если что-то случится — помогут.",
    economics: {
      mileage: "16 724 км",
      rate: "74,93 руб./км",
      revenue: "1 253 115 ₽",
      expenses: "478 954 ₽",
      profit: "774 226 ₽",
      expensesNote: "ГСМ, ТО, Ремонт, страхование, Платон, платные дороги",
    },
  },
];

const CaseArticle = ({ c, sheetEconomics }: { c: typeof cases[0]; sheetEconomics?: CaseEconomics }) => {
  const eco = sheetEconomics || c.economics;
  return (
  <article className="bg-card rounded-2xl overflow-hidden">
    <div className="p-6 sm:p-8 border-b border-border">
      <div className="flex items-center gap-4 mb-5">
        {avatars[c.id] ? (
          <img src={avatars[c.id]} alt={c.name} className="w-12 h-12 sm:w-14 sm:h-14 rounded-full object-cover shrink-0" />
        ) : (
        <div className="w-12 h-12 sm:w-14 sm:h-14 rounded-full bg-muted flex items-center justify-center shrink-0">
          <User className="w-5 h-5 sm:w-6 sm:h-6 text-muted-foreground" />
        </div>
        )}
        <div>
          <h2 className="text-foreground font-bold text-lg sm:text-xl leading-tight">{c.name}</h2>
          <p className="text-muted-foreground text-sm mt-0.5">{c.entity} · {c.type}</p>
        </div>
      </div>

      <div className="flex flex-wrap gap-2">
        <span className="text-xs font-bold text-accent-warm bg-accent-warm/10 rounded-lg px-3 py-1.5 inline-flex items-center gap-1.5">
          <Truck className="w-3.5 h-3.5" />
          {c.trucks}
        </span>
        <span className="text-xs font-semibold text-muted-foreground bg-muted rounded-lg px-3 py-1.5">
          {c.mode}
        </span>
      </div>
    </div>

    <div className="p-6 sm:p-8">
      <div className="space-y-6 mb-8">
        <div>
          <h3 className="text-foreground font-bold text-sm mb-2">О партнере</h3>
          <p className="text-muted-foreground text-sm leading-relaxed">{c.background}</p>
        </div>
        <div>
          <h3 className="text-foreground font-bold text-sm mb-2">Цель</h3>
          <p className="text-muted-foreground text-sm leading-relaxed">{c.goal}</p>
        </div>
        <div>
          <h3 className="text-foreground font-bold text-sm mb-2">История</h3>
          <p className="text-muted-foreground text-sm leading-relaxed">{c.story}</p>
        </div>

        <div className="bg-background rounded-xl p-4">
          <h3 className="text-foreground font-bold text-sm mb-2">Состав парка</h3>
          <p className="text-muted-foreground text-sm leading-relaxed">{c.truckDetail}</p>
        </div>
      </div>

      <div className="bg-primary rounded-2xl p-6 mb-8">
        <Quote className="w-5 h-5 text-primary-foreground/30 mb-2" />
        <p className="text-primary-foreground text-sm leading-relaxed italic">
          «{c.review}»
        </p>
        <p className="text-primary-foreground/70 text-sm font-bold mt-3">— {c.name}</p>
      </div>

      <div className="bg-background rounded-2xl p-5 sm:p-6">
        <h3 className="text-foreground font-bold text-sm mb-4">Экономика</h3>

        {[
          { label: "Пробег", value: eco.mileage },
          { label: "Средняя ставка", value: eco.rate },
          { label: "Выручка", value: eco.revenue },
        ].map((row) => (
          <div key={row.label} className="flex justify-between items-center py-2.5 border-b border-border text-sm">
            <span className="text-muted-foreground">{row.label}</span>
            <span className="text-foreground font-bold tabular-nums">{row.value}</span>
          </div>
        ))}

        <div className="flex justify-between items-start py-2.5 border-b border-border text-sm gap-3">
          <div className="min-w-0">
            <div className="text-muted-foreground">Расходы</div>
            <div className="text-xs text-muted-foreground/60 mt-0.5 leading-relaxed">{eco.expensesNote}</div>
          </div>
          <span className="text-foreground font-bold tabular-nums shrink-0">{eco.expenses}</span>
        </div>

        <div className="flex justify-between items-center mt-3 bg-primary/10 rounded-xl px-4 py-3">
          <span className="text-primary font-bold text-sm">Прибыль</span>
          <span className="text-primary font-bold tabular-nums text-lg">{eco.profit}</span>
        </div>
      </div>
    </div>
  </article>
  );
};

const CasesPage = () => {
  const { id } = useParams();
  const navigate = useNavigate();
  const sheetData = useCaseEconomics();

  const selectedCase = id ? cases.find((c) => c.id === id) : null;
  const displayCases = selectedCase ? [selectedCase] : cases;

  return (
    <div className="min-h-screen bg-background text-foreground">
      <header className="fixed top-0 left-0 right-0 z-50 bg-background border-b border-border">
        <div className="container-landing flex items-center justify-between h-16 px-5 sm:px-8 lg:px-12">
          <button onClick={() => navigate(-1)} className="flex items-center gap-2 bg-primary text-primary-foreground hover:bg-primary/90 transition-colors text-sm font-bold px-4 py-2 rounded-xl">
            <ArrowLeft className="w-4 h-4" />
            Закрыть
          </button>
          <span className="font-bold text-sm text-foreground tracking-tight">
            Орда <span className="text-primary">Партнер Парк</span>
          </span>
          <div className="w-4 h-4" aria-hidden />
        </div>
      </header>

      <div className="container-landing px-5 sm:px-8 lg:px-12 pt-28 pb-20">
        <div className="mb-10">
          <h1 className="font-bold text-foreground leading-tight" style={{ fontSize: "clamp(1.75rem, 4vw, var(--type-2xl))" }}>
            Истории <span className="text-primary">партнеров</span>
          </h1>
          <p className="text-muted-foreground text-sm mt-3 max-w-lg leading-relaxed">
            Реальные истории и отзывы участников проекта Партнер Парк
          </p>
        </div>

        <div className="space-y-6">
          {displayCases.map((c) => (
            <CaseArticle key={c.id} c={c} sheetEconomics={sheetData[c.id]} />
          ))}
        </div>

        <div className="mt-14 text-center">
          <Link to="/#cta" className="btn-primary rounded-xl">
            Хочу стать партнером →
          </Link>
        </div>
      </div>
    </div>
  );
};

export default CasesPage;
