/**
 * Backup page: version of cases section with bar charts and monthly economics dialogs.
 * Route: /cases-charts
 * Kept for potential future use.
 */
import CasesSectionWithCharts from "@/components/CasesSectionWithCharts";

const CasesChartsPage = () => (
  <div className="min-h-screen bg-background">
    <CasesSectionWithCharts />
  </div>
);

export default CasesChartsPage;
