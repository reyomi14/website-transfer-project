import Header from "@/components/Header";
import HeroSection from "@/components/HeroSection";
import AboutProjectSection from "@/components/AboutProjectSection";
import ForWhomSection from "@/components/ForWhomSection";
import ComparisonSection from "@/components/ComparisonSection";
import HowItWorksSection from "@/components/HowItWorksSection";
import EconomicsSection from "@/components/EconomicsSection";
import RatesMythSection from "@/components/RatesMythSection";
import ServicesSection from "@/components/ServicesSection";
import ResponsibilitiesSection from "@/components/ResponsibilitiesSection";
import CasesSection from "@/components/CasesSection";
import FaqSection from "@/components/FaqSection";
import LimitSection from "@/components/LimitSection";
import ParentCompanySection from "@/components/ParentCompanySection";
import CtaSection from "@/components/CtaSection";
import Footer from "@/components/Footer";

const Index = () => {
  return (
    <>
      <Header />
      {/* SWISS: Header height = 56px (h-14) */}
      <main className="pt-16 bg-background">
        <HeroSection />
        <AboutProjectSection />
        <ForWhomSection />
        <ComparisonSection />
        <HowItWorksSection />
        <EconomicsSection />
        <CasesSection />
        <RatesMythSection />
        <ServicesSection />
        <ResponsibilitiesSection />
        <FaqSection />
        <LimitSection />
        <CtaSection />
        <ParentCompanySection />
      </main>
      <Footer />
    </>
  );
};

export default Index;