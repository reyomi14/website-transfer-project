import { corsHeaders } from "../_shared/cors.ts";

const GATEWAY_URL = 'https://connector-gateway.lovable.dev/telegram';
const CHAT_ID = -5161827180;

const GOOGLE_FORM_URL =
  "https://docs.google.com/forms/d/e/1FAIpQLSfHaBgjiqmP-GGpQYqeh6-kJmqt0shGPZxdFNODP2Qh-zAHBg/formResponse";

async function sendToGoogleForm(name: string, phone: string, trucks: string) {
  const params = new URLSearchParams();
  params.set("entry.406531471", name);
  params.set("entry.215230857", phone);
  params.set("entry.1768863336", trucks || "");

  const res = await fetch(GOOGLE_FORM_URL, {
    method: "POST",
    headers: { "Content-Type": "application/x-www-form-urlencoded" },
    body: params.toString(),
  });
  await res.text();
  return res.ok;
}

async function sendToBitrix(name: string, phone: string, trucks: string, timezone = '', localDateTime = '', utm: Record<string, string> = {}, formTitle = 'Заявка ПП Орда') {
  const BITRIX_WEBHOOK_URL = Deno.env.get('BITRIX_WEBHOOK_URL');
  if (!BITRIX_WEBHOOK_URL) {
    console.error('BITRIX_WEBHOOK_URL is not configured');
    return false;
  }

  const utmFields: Record<string, string> = {};
  if (utm?.utm_source) utmFields['UTM_SOURCE'] = utm.utm_source;
  if (utm?.utm_medium) utmFields['UTM_MEDIUM'] = utm.utm_medium;
  if (utm?.utm_campaign) utmFields['UTM_CAMPAIGN'] = utm.utm_campaign;
  if (utm?.utm_term) utmFields['UTM_TERM'] = utm.utm_term;
  if (utm?.utm_content) utmFields['UTM_CONTENT'] = utm.utm_content;

  const url = `${BITRIX_WEBHOOK_URL.replace(/\/$/, '')}/crm.lead.add.json`;

  const res = await fetch(url, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      fields: {
        TITLE: formTitle,
        NAME: name,
        PHONE: [{ VALUE: phone, VALUE_TYPE: 'WORK' }],
        COMMENTS: [formTitle, trucks ? `Кол-во фур: ${trucks}` : 'Запрос ставки по маршруту', timezone ? `Часовой пояс: ${timezone}` : '', localDateTime ? `Локальное время заявки: ${localDateTime}` : ''].filter(Boolean).join('\n'),
        SOURCE_ID: 'WEB',
        ...utmFields,
      },
    }),
  });

  const data = await res.json();
  if (!res.ok) {
    console.error(`Bitrix API failed [${res.status}]:`, data);
    return false;
  }
  return true;
}

Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response('ok', { headers: corsHeaders });
  }

  try {
    const LOVABLE_API_KEY = Deno.env.get('LOVABLE_API_KEY');
    if (!LOVABLE_API_KEY) throw new Error('LOVABLE_API_KEY is not configured');

    const TELEGRAM_API_KEY = Deno.env.get('TELEGRAM_API_KEY');
    if (!TELEGRAM_API_KEY) throw new Error('TELEGRAM_API_KEY is not configured');

    const { name, phone, trucks, timezone, localDateTime, utm, formType } = await req.json();

    if (!name || !phone) {
      return new Response(JSON.stringify({ error: 'name and phone are required' }), {
        status: 400,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      });
    }

    const formTitle = formType === 'rate_request' ? 'Заявка: узнать ставку по маршруту' : 'Заявка ПП Орда';

    // Build UTM line for Telegram
    const utmParts: string[] = [];
    if (utm?.utm_source) utmParts.push(`source: ${utm.utm_source}`);
    if (utm?.utm_medium) utmParts.push(`medium: ${utm.utm_medium}`);
    if (utm?.utm_campaign) utmParts.push(`campaign: ${utm.utm_campaign}`);
    if (utm?.utm_term) utmParts.push(`term: ${utm.utm_term}`);
    if (utm?.utm_content) utmParts.push(`content: ${utm.utm_content}`);
    const utmLine = utmParts.length ? `\n🔗 <b>UTM:</b> ${utmParts.join(' / ')}` : '';

    // Send to Google Forms, Telegram, and Bitrix in parallel
    const timezoneLine = timezone ? `\n🕒 <b>Часовой пояс:</b> ${timezone}` : '';
    const localDateTimeLine = localDateTime ? `\n⏱ <b>Локальное время заявки:</b> ${localDateTime}` : '';
    const text = `📋 <b>${formTitle}</b>\n\n👤 <b>Имя:</b> ${name}\n📞 <b>Телефон:</b> ${phone}\n🚛 <b>Кол-во фур:</b> ${trucks || '—'}${timezoneLine}${localDateTimeLine}${utmLine}`;

    const [googleOk, telegramRes, bitrixOk] = await Promise.all([
      sendToGoogleForm(name, phone, trucks).catch((err) => {
        console.error('Google Form error:', err);
        return false;
      }),
      fetch(`${GATEWAY_URL}/sendMessage`, {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${LOVABLE_API_KEY}`,
          'X-Connection-Api-Key': TELEGRAM_API_KEY,
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          chat_id: CHAT_ID,
          text,
          parse_mode: 'HTML',
        }),
      }).catch((err) => {
        console.error('Telegram fetch error:', err);
        return null;
      }),
      sendToBitrix(name, phone, trucks, timezone, localDateTime, utm, formTitle).catch((err) => {
        console.error('Bitrix error:', err);
        return false;
      }),
    ]);

    let telegramOk = false;
    if (telegramRes) {
      const data = await telegramRes.json();
      telegramOk = telegramRes.ok;
      if (!telegramOk) {
        console.error(`Telegram API failed [${telegramRes.status}]:`, data);
      }
    }

    return new Response(JSON.stringify({ success: true, google: googleOk, telegram: telegramOk, bitrix: bitrixOk }), {
      status: 200,
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    });
  } catch (error) {
    console.error('Error processing submission:', error);
    const msg = error instanceof Error ? error.message : 'Unknown error';
    return new Response(JSON.stringify({ success: false, error: msg }), {
      status: 500,
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    });
  }
});